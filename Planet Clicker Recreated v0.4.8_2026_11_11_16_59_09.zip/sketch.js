let game = {
  clicks: 0,
  rebirths: 0,
  rebirthCost: 1000000,
  baseSize: 180,
  targetSize: 180,
  currentSize: 180,
  x: 0,
  y: 0,
  defaultX: 0,
  shiftedX: 0,
  particles: [],
  stars: [],
  floatTexts: [],
  shopOpen: false,
  planetSelectOpen: false,
  sidebarX: 0,
  planetMenuY: 0,
  scrollY: 0,
  targetScrollY: 0,
  shopContentHeight: 0,
  planetScrollY: 0,
  planetTargetScrollY: 0,
  planetContentHeight: 0,
  activePlanetIndex: 0,
  achievementsScrollY: 0,
  achievementsTargetScrollY: 0,
  achievementsContentHeight: 0,
  creditsScrollY: 0,
  creditsTargetScrollY: 0,
  creditsContentHeight: 0,
  creditsStartTimer: 0,
  isCreditsAutoScrolling: true,
  
  menuHeroTargetX: 0,
  menuHeroTargetY: 0,
  menuHeroX: 0,
  menuHeroY: 0,
  
  gameState: 'SETUP_WIZARD',
  setupStep: 0,
  activeOverlay: null,
  activeTab: 'GENERAL',
  selectedMenuIndex: 0,
  remappingKeyId: null,

  settings: {
    musicEnabled: true,
    sfxEnabled: true,
    currentTheme: 'Dark',
    accentColor: '#00dcff',
    spacebarClicking: true,
    starCount: 140,
    starSpeed: 1.0,
    starDistance: 1.0,
    starsEnabled: true,
    uiScale: 1.0,
    brightness: 1.0,
    fullscreen: false,
    toastSize: 1.0,
    showFPS: true,
    targetFPS: 60,
    resolutionMode: 'Auto',
    keys: {
      shop: 'U',
      planets: 'P',
      pause: 'ESCAPE',
      click: 'SPACE',
      upg_C: '1',
      upg_A: '2',
      upg_S: '3',
      upg_P1: '4',
      upg_Q: '5',
      upg_P2: '6',
      upg_B: '7',
      upg_P3: '8',
      upg_D: '9',
      upg_P4: '0',
      upg_G: 'Q',
      upg_P5: 'W',
      upg_M: 'E',
      upg_P6: 'R',
      upg_T: 'T',
      upg_P7: 'Y',
      upg_X: 'I',
      upg_P8: 'O'
    }
  },

  deleteInputText: '',
  deleteInputActive: false,
  deleteWipesWizard: false,

  links: {
    youtube: "https://www.webpagetest.org/blank.html",
    discord: "https://www.webpagetest.org/blank.html",
    form: "https://docs.google.com/forms/d/e/1FAIpQLScJ_B2QA2nkzBp0O1Qan72fgzUauEb6P-xZbHdiCiQvYiv26Q/viewform?usp=dialog"
  },

  stats: {
    cometsClicked: 0,
    darkCometsClicked: 0,
    totalUpgradesBought: 0
  },
  
  achievementToast: {
    active: false,
    title: '',
    timer: 0,
    animX: 350
  },
  
  achievements: [
    { id: 'c1', name: 'First Steps', desc: 'Reach 1 total click', unlocked: false, reqType: 'clicks', reqValue: 1 },
    { id: 'c2', name: 'Star Gazer', desc: 'Reach 100 total clicks', unlocked: false, reqType: 'clicks', reqValue: 100 },
    { id: 'c3', name: 'Cosmic Explorer', desc: 'Reach 1,000 total clicks', unlocked: false, reqType: 'clicks', reqValue: 1000 },
    { id: 'c4', name: 'Space Millionaire', desc: 'Reach 1,000,000 clicks', unlocked: false, reqType: 'clicks', reqValue: 1000000 },
    { id: 'c5', name: 'Billionaire Tycoon', desc: 'Reach 1,000,000,000 clicks', unlocked: false, reqType: 'clicks', reqValue: 1000000000 },
    { id: 'c6', name: 'Galactic Overlord', desc: 'Reach 1 Trillion clicks', unlocked: false, reqType: 'clicks', reqValue: 1000000000000 },
    { id: 'c7', name: 'Universal Sovereign', desc: 'Reach 1 Quadrillion clicks', unlocked: false, reqType: 'clicks', reqValue: 1000000000000000 },
    { id: 'c8', name: 'God of Creation', desc: 'Reach 1 Quintillion clicks', unlocked: false, reqType: 'clicks', reqValue: 1000000000000000000 },
    { id: 'cps1', name: 'Automated Future', desc: 'Reach 10 CPS', unlocked: false, reqType: 'cps', reqValue: 10 },
    { id: 'cps2', name: 'Factory Planet', desc: 'Reach 500 CPS', unlocked: false, reqType: 'cps', reqValue: 500 },
    { id: 'cps3', name: 'Engine of Creation', desc: 'Reach 25,000 CPS', unlocked: false, reqType: 'cps', reqValue: 25000 },
    { id: 'cps4', name: 'Power Plant Master', desc: 'Reach 1,000,000 CPS', unlocked: false, reqType: 'cps', reqValue: 1000000 },
    { id: 'cps5', name: 'Quantum Core', desc: 'Reach 100 Million CPS', unlocked: false, reqType: 'cps', reqValue: 100000000 },
    { id: 'cps6', name: 'Hyper-Drive Production', desc: 'Reach 10 Billion CPS', unlocked: false, reqType: 'cps', reqValue: 10000000000 },
    { id: 'cps7', name: 'Infinite Energy', desc: 'Reach 1 Trillion CPS', unlocked: false, reqType: 'cps', reqValue: 1000000000000 },
    { id: 'p1', name: 'New Horizon', desc: 'Unlock Pyronis', unlocked: false, reqType: 'planets', reqValue: 2 },
    { id: 'p2', name: 'Gale Force', desc: 'Unlock Zephyrus', unlocked: false, reqType: 'planets', reqValue: 3 },
    { id: 'p3', name: 'Overgrowth', desc: 'Unlock Virelia', unlocked: false, reqType: 'planets', reqValue: 4 },
    { id: 'p4', name: 'Into the Shadow', desc: 'Unlock Oblivion', unlocked: false, reqType: 'planets', reqValue: 5 },
    { id: 'p5', name: 'Golden Dominion', desc: 'Unlock Aethelgard', unlocked: false, reqType: 'planets', reqValue: 6 },
    { id: 'p6', name: 'Sub-Zero', desc: 'Unlock Glacies', unlocked: false, reqType: 'planets', reqValue: 7 },
    { id: 'p7', name: 'Master of Time', desc: 'Unlock Chronos', unlocked: false, reqType: 'planets', reqValue: 8 },
    { id: 'p8', name: 'Deep Space Ruler', desc: 'Unlock All 14 Planets', unlocked: false, reqType: 'planets', reqValue: 14 },
    { id: 'comet1', name: 'Stardust Catcher', desc: 'Click 1 Golden Comet', unlocked: false, reqType: 'comet', reqValue: 1 },
    { id: 'comet2', name: 'Meteor Hunter', desc: 'Click 5 Golden Comets', unlocked: false, reqType: 'comet', reqValue: 5 },
    { id: 'comet3', name: 'Comet Chaser', desc: 'Click 15 Golden Comets', unlocked: false, reqType: 'comet', reqValue: 15 },
    { id: 'comet4', name: 'Astronomer Supreme', desc: 'Click 50 Golden Comets', unlocked: false, reqType: 'comet', reqValue: 50 },
    { id: 'dcomet1', name: 'Dark Void Hunter', desc: 'Click 1 Dark Asteroid', unlocked: false, reqType: 'dark_comet', reqValue: 1 },
    { id: 'dcomet2', name: 'Shadow Collector', desc: 'Click 10 Dark Asteroids', unlocked: false, reqType: 'dark_comet', reqValue: 10 },
    { id: 'upg1', name: 'Tinker', desc: 'Buy 5 total upgrades', unlocked: false, reqType: 'upgrades', reqValue: 5 },
    { id: 'upg2', name: 'Engineer', desc: 'Buy 25 total upgrades', unlocked: false, reqType: 'upgrades', reqValue: 25 },
    { id: 'upg3', name: 'Grand Architect', desc: 'Buy 100 total upgrades', unlocked: false, reqType: 'upgrades', reqValue: 100 }
  ],
  
  asteroid: { active: false, x: 0, y: 0, vx: 0, vy: 0, size: 38, spawnTimer: 0 },
  darkAsteroid: { active: false, x: 0, y: 0, vx: 0, vy: 0, size: 42, spawnTimer: 0 },
  
  planets: [
    { id: 'sun', name: 'Sun', cost: 0, unlocked: true, color: [0, 220, 255], primaryColor: '#00dcff', secondaryColor: '#008cff', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'pyronis', name: 'Pyronis', cost: 15000, unlocked: false, color: [255, 70, 30], primaryColor: '#ff461e', secondaryColor: '#ff7800', outlineColor: '#ffc800', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'zephyrus', name: 'Zephyrus', cost: 250000, unlocked: false, color: [160, 90, 240], primaryColor: '#a05af0', secondaryColor: '#c8a0ff', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'virelia', name: 'Virelia', cost: 5000000, unlocked: false, color: [40, 230, 120], primaryColor: '#28e678', secondaryColor: '#009650', outlineColor: '#a0ffc8', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'oblivion', name: 'Oblivion', cost: 100000000, unlocked: false, color: [180, 50, 255], primaryColor: '#b432ff', secondaryColor: '#640096', outlineColor: '#ff00ff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'aethelgard', name: 'Aethelgard', cost: 2000000000, unlocked: false, color: [255, 215, 0], primaryColor: '#ffd700', secondaryColor: '#ff9000', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'glacies', name: 'Glacies', cost: 45000000000, unlocked: false, color: [150, 230, 255], primaryColor: '#96e6ff', secondaryColor: '#00a0e6', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'chronos', name: 'Chronos', cost: 800000000000, unlocked: false, color: [255, 120, 180], primaryColor: '#ff78b4', secondaryColor: '#b42878', outlineColor: '#ffd700', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'nebula', name: 'Nebula', cost: 15000000000000, unlocked: false, color: [255, 80, 200], primaryColor: '#ff50c8', secondaryColor: '#960078', outlineColor: '#00ffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'solaris', name: 'Solaris', cost: 300000000000000, unlocked: false, color: [255, 200, 80], primaryColor: '#ffc850', secondaryColor: '#ff6400', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'toxica', name: 'Toxica', cost: 6000000000000000, unlocked: false, color: [120, 255, 60], primaryColor: '#78ff3c', secondaryColor: '#329600', outlineColor: '#00ff00', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'abyss', name: 'Abyss', cost: 100000000000000000, unlocked: false, color: [80, 100, 255], primaryColor: '#5064ff', secondaryColor: '#140064', outlineColor: '#80a0ff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'lumina', name: 'Lumina', cost: 2500000000000000000, unlocked: false, color: [255, 255, 200], primaryColor: '#ffffc8', secondaryColor: '#ffaa00', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 },
    { id: 'ether', name: 'Aetheria', cost: 50000000000000000000, unlocked: false, color: [200, 100, 255], primaryColor: '#c864ff', secondaryColor: '#00ffff', outlineColor: '#ffffff', speedScale: 1.0, particleDensity: 1.0 }
  ],

  upgrades: [
    { id: 'C', name: 'Click Power', level: 1, cost: 25, power: 1, type: 'click', reqPlanet: 0, currentHover: 0 },
    { id: 'A', name: 'Auto Clicker', level: 0, cost: 50, power: 1, type: 'cps', reqPlanet: 0, currentHover: 0 },
    { id: 'S', name: 'Solar Farm', level: 0, cost: 300, power: 3, type: 'cps', reqPlanet: 0, currentHover: 0 },
    { id: 'P1', name: 'Pyronis Flare', level: 0, cost: 15000, power: 0.5, type: 'multiplier', reqPlanet: 1, currentHover: 0 },
    { id: 'Q', name: 'Quantum Engine', level: 0, cost: 800, power: 25, type: 'cps', reqPlanet: 0, currentHover: 0 },
    { id: 'P2', name: 'Zephyr Stream', level: 0, cost: 300000, power: 1200, type: 'cps', reqPlanet: 2, currentHover: 0 },
    { id: 'B', name: 'Star Boost', level: 0, cost: 3000, power: 0.25, type: 'multiplier', reqPlanet: 0, currentHover: 0 },
    { id: 'P3', name: 'Virelia Bio-Core', level: 0, cost: 6000000, power: 1.0, type: 'multiplier', reqPlanet: 3, currentHover: 0 },
    { id: 'D', name: 'Dyson Sphere', level: 0, cost: 50000, power: 600, type: 'cps', reqPlanet: 0, currentHover: 0 },
    { id: 'P4', name: 'Oblivion Forge', level: 0, cost: 120000000, power: 120000, type: 'cps', reqPlanet: 4, currentHover: 0 },
    { id: 'G', name: 'Galactic Net', level: 0, cost: 1500000, power: 10000, type: 'cps', reqPlanet: 0, currentHover: 0 },
    { id: 'P5', name: 'Aethelgard Relic', level: 0, cost: 3000000000, power: 2.0, type: 'multiplier', reqPlanet: 5, currentHover: 0 },
    { id: 'M', name: 'Dark Matter', level: 0, cost: 25000000, power: 200000, type: 'cps', reqPlanet: 0, currentHover: 0 },
    { id: 'P6', name: 'Glacies Zero Core', level: 0, cost: 60000000000, power: 3000000, type: 'cps', reqPlanet: 6, currentHover: 0 },
    { id: 'T', name: 'Time Warp', level: 0, cost: 500000000, power: 1.0, type: 'multiplier', reqPlanet: 0, currentHover: 0 },
    { id: 'P7', name: 'Chronos Paradox', level: 0, cost: 1000000000000, power: 3.0, type: 'multiplier', reqPlanet: 7, currentHover: 0 },
    { id: 'X', name: 'Singularity', level: 0, cost: 20000000000, power: 8000, type: 'click', reqPlanet: 0, currentHover: 0 },
    { id: 'P8', name: 'Aetherial Matrix', level: 0, cost: 8000000000000000000, power: 5.0, type: 'multiplier', reqPlanet: 13, currentHover: 0 }
  ]
};

const PLANET_DEFAULTS = [
  { id: 'sun', primaryColor: '#00dcff', secondaryColor: '#008cff', outlineColor: '#ffffff' },
  { id: 'pyronis', primaryColor: '#ff461e', secondaryColor: '#ff7800', outlineColor: '#ffc800' },
  { id: 'zephyrus', primaryColor: '#a05af0', secondaryColor: '#c8a0ff', outlineColor: '#ffffff' },
  { id: 'virelia', primaryColor: '#28e678', secondaryColor: '#009650', outlineColor: '#a0ffc8' },
  { id: 'oblivion', primaryColor: '#b432ff', secondaryColor: '#640096', outlineColor: '#ff00ff' },
  { id: 'aethelgard', primaryColor: '#ffd700', secondaryColor: '#ff9000', outlineColor: '#ffffff' },
  { id: 'glacies', primaryColor: '#96e6ff', secondaryColor: '#00a0e6', outlineColor: '#ffffff' },
  { id: 'chronos', primaryColor: '#ff78b4', secondaryColor: '#b42878', outlineColor: '#ffd700' },
  { id: 'nebula', primaryColor: '#ff50c8', secondaryColor: '#960078', outlineColor: '#00ffff' },
  { id: 'solaris', primaryColor: '#ffc850', secondaryColor: '#ff6400', outlineColor: '#ffffff' },
  { id: 'toxica', primaryColor: '#78ff3c', secondaryColor: '#329600', outlineColor: '#00ff00' },
  { id: 'abyss', primaryColor: '#5064ff', secondaryColor: '#140064', outlineColor: '#80a0ff' },
  { id: 'lumina', primaryColor: '#ffffc8', secondaryColor: '#ffaa00', outlineColor: '#ffffff' },
  { id: 'ether', primaryColor: '#c864ff', secondaryColor: '#00ffff', outlineColor: '#ffffff' }
];

const THEMES = {
  'Dark': { bg: [10, 8, 20], sidebar: [18, 18, 38], panel: [15, 15, 30], text: [255, 255, 255] },
  'Xtra Dark': { bg: [2, 2, 5], sidebar: [8, 8, 12], panel: [6, 6, 10], text: [220, 220, 220] },
  'Contrast': { bg: [0, 0, 0], sidebar: [20, 20, 20], panel: [30, 30, 30], text: [255, 255, 255] },
  'Color Blind': { bg: [15, 20, 25], sidebar: [25, 35, 45], panel: [20, 30, 40], text: [255, 255, 255] },
  'Light Mode': { bg: [235, 240, 248], sidebar: [215, 225, 238], panel: [255, 255, 255], text: [20, 30, 45] }
};

const ACCENT_PRESETS = ['#00dcff', '#ff461e', '#a05af0', '#28e678', '#ffd700', '#ff78b4', '#ffffff', '#ff9000'];

function hexToRgb(hex) {
  let c = color(hex || '#ffffff');
  return [red(c), green(c), blue(c)];
}

function getTheme() {
  let baseTheme = THEMES[game.settings.currentTheme] || THEMES['Dark'];
  let accentRgb = hexToRgb(game.settings.accentColor);
  return {
    bg: baseTheme.bg,
    sidebar: baseTheme.sidebar,
    panel: baseTheme.panel,
    text: baseTheme.text,
    accent: accentRgb
  };
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("Arial");
  
  if (hasSaveFile()) {
    loadGame();
    game.gameState = 'MAIN_MENU';
  } else {
    game.gameState = 'SETUP_WIZARD';
    game.setupStep = 0;
  }
  
  updateDimensions();
  rebuildStars();
  frameRate(game.settings.targetFPS);
}

function rebuildStars() {
  game.stars = [];
  for (let i = 0; i < game.settings.starCount; i++) {
    let bSize = random(1, 3.5);
    game.stars.push({
      x: random(width),
      y: random(height),
      z: random(0.5, 2.5),
      baseSize: bSize,
      size: bSize
    });
  }
}

function checkAchievements() {
  let unlockedPlanets = game.planets.filter(p => p.unlocked).length;
  let totalCPS = calculateCPS();

  game.achievements.forEach(ach => {
    if (!ach.unlocked) {
      let conditionMet = false;

      if (ach.reqType === 'clicks' && game.clicks >= ach.reqValue) conditionMet = true;
      if (ach.reqType === 'cps' && totalCPS >= ach.reqValue) conditionMet = true;
      if (ach.reqType === 'planets' && unlockedPlanets >= ach.reqValue) conditionMet = true;
      if (ach.reqType === 'comet' && game.stats.cometsClicked >= ach.reqValue) conditionMet = true;
      if (ach.reqType === 'dark_comet' && game.stats.darkCometsClicked >= ach.reqValue) conditionMet = true;
      if (ach.reqType === 'upgrades' && game.stats.totalUpgradesBought >= ach.reqValue) conditionMet = true;

      if (conditionMet) {
        ach.unlocked = true;
        triggerAchievementToast(ach.name);
        saveGame();
      }
    }
  });
}

function triggerAchievementToast(title) {
  game.achievementToast.active = true;
  game.achievementToast.title = title;
  game.achievementToast.timer = 200;
  game.achievementToast.animX = 350;
}

function drawAchievementToast() {
  let toast = game.achievementToast;
  if (!toast.active) return;

  if (toast.timer > 30) {
    toast.animX = lerp(toast.animX, 0, 0.15);
  } else {
    toast.animX = lerp(toast.animX, 350, 0.15);
  }

  toast.timer--;
  if (toast.timer <= 0) {
    toast.active = false;
    return;
  }

  let scale = game.settings.uiScale;
  let w = 300 * scale;
  let h = 65 * scale;
  let x = width - w - 20 + toast.animX;
  let y = height - h - 20;

  fill(15, 20, 35, 235);
  stroke(255, 215, 0);
  strokeWeight(2 * scale);
  rect(x, y, w, h, 8 * scale);

  noStroke();
  textAlign(LEFT, CENTER);
  fill(255, 215, 0);
  textSize(12 * scale);
  textStyle(BOLD);
  text("ACHIEVEMENT UNLOCKED!", x + 15 * scale, y + 20 * scale);

  fill(255);
  textSize(14 * scale);
  text(toast.title, x + 15 * scale, y + 42 * scale);
}

function performRebirth() {
  if (game.clicks >= game.rebirthCost) {
    game.rebirths += 1;
    game.clicks = 0;
    game.rebirthCost = Math.floor(game.rebirthCost * 5.0);

    let defaultCosts = [25, 50, 300, 15000, 800, 300000, 3000, 6000000, 50000, 120000000, 1500000, 3000000000, 25000000, 60000000000, 500000000, 1000000000000, 20000000000, 8000000000000000000];
    for (let i = 0; i < game.upgrades.length; i++) {
      game.upgrades[i].level = (i === 0) ? 1 : 0;
      game.upgrades[i].cost = Math.floor(defaultCosts[i] * Math.pow(1.5, game.rebirths));
    }

    game.floatTexts.push(new FloatText(game.x, game.y, `REBIRTH #${game.rebirths}! (+${(game.rebirths * 10)}% MULTIPLIER)`));
    for (let i = 0; i < 40; i++) game.particles.push(new Particle(game.x, game.y, [255, 215, 0]));
    saveGame();
  }
}

function saveGame() {
  let saveData = {
    clicks: game.clicks,
    rebirths: game.rebirths,
    rebirthCost: game.rebirthCost,
    activePlanetIndex: game.activePlanetIndex,
    settings: game.settings,
    planets: game.planets.map(p => ({
      id: p.id,
      unlocked: p.unlocked,
      primaryColor: p.primaryColor,
      secondaryColor: p.secondaryColor,
      outlineColor: p.outlineColor,
      speedScale: p.speedScale,
      particleDensity: p.particleDensity
    })),
    upgrades: game.upgrades.map(u => ({ id: u.id, level: u.level, cost: u.cost })),
    achievements: game.achievements.map(a => ({ id: a.id, unlocked: a.unlocked })),
    stats: game.stats
  };
  localStorage.setItem('PlanetClickerSave', JSON.stringify(saveData));
}

function loadGame() {
  let rawData = localStorage.getItem('PlanetClickerSave');
  if (!rawData) return false;

  let saveData = JSON.parse(rawData);
  game.clicks = saveData.clicks || 0;
  game.rebirths = saveData.rebirths || 0;
  game.rebirthCost = saveData.rebirthCost || 1000000;
  game.activePlanetIndex = saveData.activePlanetIndex || 0;
  if (saveData.settings) game.settings = Object.assign(game.settings, saveData.settings);
  if (saveData.stats) game.stats = saveData.stats;

  if (saveData.planets) {
    saveData.planets.forEach(sp => {
      let p = game.planets.find(item => item.id === sp.id);
      if (p) {
        p.unlocked = sp.unlocked;
        if (sp.primaryColor) p.primaryColor = sp.primaryColor;
        if (sp.secondaryColor) p.secondaryColor = sp.secondaryColor;
        if (sp.outlineColor) p.outlineColor = sp.outlineColor;
        if (sp.speedScale !== undefined) p.speedScale = sp.speedScale;
        if (sp.particleDensity !== undefined) p.particleDensity = sp.particleDensity;
        p.color = hexToRgb(p.primaryColor);
      }
    });
  }

  if (saveData.upgrades) {
    saveData.upgrades.forEach(su => {
      let u = game.upgrades.find(item => item.id === su.id);
      if (u) {
        u.level = su.level;
        u.cost = su.cost;
      }
    });
  }

  if (saveData.achievements) {
    saveData.achievements.forEach(sa => {
      let a = game.achievements.find(item => item.id === sa.id);
      if (a) a.unlocked = sa.unlocked;
    });
  }

  rebuildStars();
  return true;
}

function deleteSaveData() {
  localStorage.removeItem('PlanetClickerSave');
  resetGameData();
}

function hasSaveFile() {
  let rawData = localStorage.getItem('PlanetClickerSave');
  if (!rawData) return false;
  
  try {
    let saveData = JSON.parse(rawData);
    let totalUpgrades = saveData.upgrades ? saveData.upgrades.reduce((sum, u) => sum + u.level, 0) : 0;
    return (saveData.clicks > 0 || totalUpgrades > 1 || saveData.rebirths > 0);
  } catch (e) {
    return false;
  }
}

function resetTabDefaults(tab) {
  if (tab === 'GENERAL') {
    game.settings.musicEnabled = true;
    game.settings.sfxEnabled = true;
    game.settings.spacebarClicking = true;
  } else if (tab === 'VIDEO') {
    game.settings.currentTheme = 'Dark';
    game.settings.accentColor = '#00dcff';
    game.settings.starCount = 140;
    game.settings.starSpeed = 1.0;
    game.settings.starDistance = 1.0;
    game.settings.starsEnabled = true;
    game.settings.uiScale = 1.0;
    game.settings.brightness = 1.0;
    game.settings.resolutionMode = 'Auto';
    game.settings.toastSize = 1.0;
    game.settings.showFPS = true;
    game.settings.targetFPS = 60;
    frameRate(60);
    rebuildStars();
  } else if (tab === 'CONTROLS') {
    game.settings.keys = {
      shop: 'U', planets: 'P', pause: 'ESCAPE', click: 'SPACE',
      upg_C: '1', upg_A: '2', upg_S: '3', upg_P1: '4', upg_Q: '5', upg_P2: '6',
      upg_B: '7', upg_P3: '8', upg_D: '9', upg_P4: '0', upg_G: 'Q', upg_P5: 'W',
      upg_M: 'E', upg_P6: 'R', upg_T: 'T', upg_P7: 'Y', upg_X: 'I', upg_P8: 'O'
    };
  } else if (tab === 'GAMEPLAY') {
    game.settings.spacebarClicking = true;
  }
}

function resetAllSettingsDefaults() {
  resetTabDefaults('GENERAL');
  resetTabDefaults('VIDEO');
  resetTabDefaults('CONTROLS');
  resetTabDefaults('GAMEPLAY');
}

function resetGameData() {
  game.clicks = 0;
  game.rebirths = 0;
  game.rebirthCost = 1000000;
  game.activePlanetIndex = 0;
  game.shopOpen = false;
  game.planetSelectOpen = false;
  game.scrollY = 0;
  game.targetScrollY = 0;
  game.planetScrollY = 0;
  game.planetTargetScrollY = 0;
  game.achievementsScrollY = 0;
  game.achievementsTargetScrollY = 0;
  game.stats.cometsClicked = 0;
  game.stats.darkCometsClicked = 0;
  game.stats.totalUpgradesBought = 0;
  
  for (let i = 0; i < game.planets.length; i++) {
    let def = PLANET_DEFAULTS.find(d => d.id === game.planets[i].id);
    game.planets[i].unlocked = (i === 0);
    game.planets[i].speedScale = 1.0;
    game.planets[i].particleDensity = 1.0;
    if (def) {
      game.planets[i].primaryColor = def.primaryColor;
      game.planets[i].secondaryColor = def.secondaryColor;
      game.planets[i].outlineColor = def.outlineColor;
      game.planets[i].color = hexToRgb(def.primaryColor);
    }
  }

  let defaultCosts = [25, 50, 300, 15000, 800, 300000, 3000, 6000000, 50000, 120000000, 1500000, 3000000000, 25000000, 60000000000, 500000000, 1000000000000, 20000000000, 8000000000000000000];
  for (let i = 0; i < game.upgrades.length; i++) {
    game.upgrades[i].level = (i === 0) ? 1 : 0;
    game.upgrades[i].cost = defaultCosts[i];
    game.upgrades[i].currentHover = 0;
  }

  game.achievements.forEach(a => a.unlocked = false);
  
  game.particles = [];
  game.floatTexts = [];
  game.asteroid.active = false;
  game.asteroid.spawnTimer = 0;
  game.darkAsteroid.active = false;
  game.darkAsteroid.spawnTimer = 0;
}

function updateDimensions() {
  game.defaultX = width / 2;
  game.x = game.shopOpen ? width / 2 - 160 : game.defaultX;
  game.y = height / 2;
  game.shiftedX = width / 2 - 160;
  game.sidebarX = game.shopOpen ? width - 320 : width;
  game.planetMenuY = game.planetSelectOpen ? 0 : height;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  updateDimensions();
}

function draw() {
  let theme = getTheme();
  
  if (game.gameState === 'SETUP_WIZARD') {
    background(0);
    drawSetupWizard();
    return;
  }

  background(theme.bg[0] * game.settings.brightness, theme.bg[1] * game.settings.brightness, theme.bg[2] * game.settings.brightness);  

  if (game.gameState !== 'PAUSED') {
    let targetX = game.shopOpen ? game.shiftedX : game.defaultX;
    game.x = lerp(game.x, targetX, 0.2); 
    
    let targetSidebarX = game.shopOpen ? width - 320 : width;
    game.sidebarX = lerp(game.sidebarX, targetSidebarX, 0.2);

    let targetPlanetMenuY = game.planetSelectOpen ? 0 : height;
    game.planetMenuY = lerp(game.planetMenuY, targetPlanetMenuY, 0.2);
  }
  
  let currentShift = game.x - game.defaultX;
  
  if (game.settings.starsEnabled) {
    fill(255 * game.settings.brightness);
    noStroke();
    for (let i = 0; i < game.stars.length; i++) {
      let st = game.stars[i];
      if (game.gameState !== 'PAUSED') {
        let pulse = sin(frameCount * 0.05 * game.settings.starSpeed + i) * 0.5;
        st.size = max(0.5, (st.baseSize + pulse) * game.settings.starDistance);
      }
      fill(255, 255, 255, random(150, 255));
      
      let rawX = st.x + currentShift * 0.3 * st.z;
      let starX = (rawX % width + width) % width;
      
      circle(starX, st.y, st.size);
    }
  }

  if (game.gameState === 'MAIN_MENU') {
    drawMainMenu();
    return;
  }

  if (game.gameState === 'PLAYING') {
    let totalCPS = calculateCPS();
    game.clicks += (totalCPS * deltaTime) / 1000;
    
    checkAchievements();

    if (frameCount % 300 === 0) {
      saveGame();
    }
    
    let d = dist(mouseX, mouseY, game.x, game.y);
    if (d < game.currentSize / 2 && !game.planetSelectOpen && game.planetMenuY > height * 0.5) {
      game.targetSize = mouseIsPressed ? game.baseSize * 0.9 : game.baseSize * 1.08;
    } else {
      game.targetSize = game.baseSize;
    }
    game.currentSize = lerp(game.currentSize, game.targetSize, 0.65);
    
    updateAsteroids();
    
    for (let i = game.particles.length - 1; i >= 0; i--) {
      game.particles[i].update();
      if (game.particles[i].isDead()) game.particles.splice(i, 1);
    }
    
    for (let i = game.floatTexts.length - 1; i >= 0; i--) {
      game.floatTexts[i].update();
      if (game.floatTexts[i].isDead()) game.floatTexts.splice(i, 1);
    }
  }

  drawActivePlanet(game.x, game.y, game.currentSize);
  drawAsteroids();

  for (let i = 0; i < game.particles.length; i++) {
    game.particles[i].display();
  }
  
  for (let i = 0; i < game.floatTexts.length; i++) {
    game.floatTexts[i].display();
  }  
  
  let totalCPS = calculateCPS();
  noStroke();
  textAlign(CENTER, TOP);
  fill(theme.text[0], theme.text[1], theme.text[2]);
  textSize(42 * game.settings.uiScale);
  textStyle(BOLD);
  text(Math.floor(game.clicks).toLocaleString(), game.x, 45);
  
  let activeCol = game.planets[game.activePlanetIndex].color;
  fill(activeCol[0], activeCol[1], activeCol[2]);
  textSize(16 * game.settings.uiScale);
  textStyle(NORMAL);
  text(`${game.planets[game.activePlanetIndex].name} | +${formatCost(totalCPS)} CPS ${game.rebirths > 0 ? `[Rebirth x${(1 + game.rebirths * 0.1).toFixed(1)}]` : ''}`, game.x, 95); 
  
  drawTopNavButtons();
  drawPauseButton();
  drawShop();
  
  if (game.planetMenuY < height - 2) {
    drawPlanetSelectOverlay();
  }

  drawAchievementToast();

  if (game.settings.showFPS) {
    fill(0, 255, 150);
    textSize(12 * game.settings.uiScale);
    textAlign(LEFT, TOP);
    text(`FPS: ${Math.round(frameRate())}`, 15, 15);
  }

  if (game.gameState === 'PAUSED') {
    drawPauseMenu();
  }
}

function drawSetupWizard() {
  background(0);
  let theme = getTheme();

  textAlign(CENTER, TOP);
  fill(theme.accent[0], theme.accent[1], theme.accent[2]);
  textSize(32);
  textStyle(BOLD);
  text("INITIAL SETUP CALIBRATION", width / 2, 40);

  if (game.setupStep === 0) {
    textSize(18); fill(255);
    text("Step 1/2: Brightness Calibration", width / 2, 100);
    textSize(14); textStyle(NORMAL); fill(200);
    text("Adjust the slider until the third star on the right is barely visible.", width / 2, 130);

    let sx = width / 2 - 150; let sy = 220;
    fill(255 * 0.9 * game.settings.brightness); circle(sx, sy, 20);
    fill(255 * 0.4 * game.settings.brightness); circle(sx + 150, sy, 20);
    fill(255 * 0.08 * game.settings.brightness); circle(sx + 300, sy, 20);

    let sliderX = width / 2 - 120; let sliderY = 320;
    stroke(100); strokeWeight(4); line(sliderX, sliderY, sliderX + 240, sliderY);
    let handleX = map(game.settings.brightness, 0.5, 1.5, sliderX, sliderX + 240);
    fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(handleX, sliderY, 20);

    textSize(14); fill(255); text(`Brightness: ${(game.settings.brightness * 100).toFixed(0)}%`, width / 2, 360);
  } else if (game.setupStep === 1) {
    textSize(18); fill(255); textStyle(BOLD);
    text("Step 2/2: UI Scale & Theme Calibration", width / 2, 90);
    textSize(13); textStyle(NORMAL); fill(200);
    text("Adjust UI scale and select your preferred visual theme below.", width / 2, 120);

    let sampleW = 380 * game.settings.uiScale;
    let sampleH = 140 * game.settings.uiScale;
    stroke(theme.accent[0], theme.accent[1], theme.accent[2]); strokeWeight(2); fill(20, 25, 45);
    rect(width / 2 - sampleW / 2, 150, sampleW, sampleH, 8);
    noStroke(); fill(255); textSize(14 * game.settings.uiScale); textAlign(CENTER, CENTER);
    text("Sample Modal Card Preview", width / 2, 150 + sampleH / 2);

    let sliderX = width / 2 - 120; let sliderY = 320;
    stroke(100); strokeWeight(4); line(sliderX, sliderY, sliderX + 240, sliderY);
    let handleX = map(game.settings.uiScale, 0.8, 1.4, sliderX, sliderX + 240);
    fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(handleX, sliderY, 20);

    textSize(14); fill(255); textAlign(CENTER, TOP);
    text(`UI Scale: ${(game.settings.uiScale * 100).toFixed(0)}%`, width / 2, 350);

    textSize(13); fill(200); text("Theme Presets:", width / 2, 385);
    let themeNames = ['Dark', 'Xtra Dark', 'Contrast', 'Color Blind', 'Light Mode'];
    for (let i = 0; i < themeNames.length; i++) {
      let tx = width / 2 - 225 + i * 92; let ty = 410;
      let isSel = (game.settings.currentTheme === themeNames[i]);
      fill(isSel ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(40));
      rect(tx, ty, 85, 26, 4);
      fill(255); textAlign(CENTER, CENTER); textSize(10); text(themeNames[i], tx + 42, ty + 13);
    }

    textSize(13); fill(200); textAlign(CENTER, TOP); text("Accent Colors:", width / 2, 450);
    for (let i = 0; i < ACCENT_PRESETS.length; i++) {
      let ax = width / 2 - 140 + i * 40; let ay = 480;
      fill(ACCENT_PRESETS[i]); stroke(game.settings.accentColor === ACCENT_PRESETS[i] ? 255 : 0);
      strokeWeight(2); circle(ax, ay, 20);
    }
  }

  fill(160); textSize(12); textStyle(NORMAL); textAlign(CENTER, BOTTOM);
  text("Note that these settings can be adjusted anytime in the Options menu.", width / 2, height - 85);

  let btnW = 180; let btnH = 45;
  let btnX = width / 2 - btnW / 2; let btnY = height - 70;

  stroke(theme.accent[0], theme.accent[1], theme.accent[2]); strokeWeight(1); fill(20, 40, 70);
  rect(btnX, btnY, btnW, btnH, 6);
  noStroke(); fill(255); textSize(15); textStyle(BOLD); textAlign(CENTER, CENTER);
  text(game.setupStep === 0 ? "NEXT" : "COMPLETE SETUP", width / 2, btnY + btnH / 2);
}

function drawMainMenu() {
  let theme = getTheme();
  fill(theme.bg[0], theme.bg[1], theme.bg[2], 180);
  rect(0, 0, width, height);

  let menuBtns = [];
  if (hasSaveFile()) menuBtns.push({ label: "CONTINUE", action: "CONTINUE" });
  menuBtns.push({ label: "NEW GAME", action: "NEW_GAME" });
  menuBtns.push({ label: "ACHIEVEMENTS", action: "ACHIEVEMENTS" });
  menuBtns.push({ label: "OPTIONS", action: "SETTINGS" });
  menuBtns.push({ label: "LINKS / COMMUNITY", action: "LINKS" });
  menuBtns.push({ label: "HELP / INSTRUCTIONS", action: "HELP" });

  let btnW = 220 * game.settings.uiScale;
  let btnH = 44 * game.settings.uiScale;
  let startX = 60;
  let startY = height * 0.30;
  let gap = 12 * game.settings.uiScale;

  let baseHeroX = width * 0.65;
  let baseHeroY = height * 0.45;
  
  let floatOffset = sin(frameCount * 0.04) * 12;

  let btnYPos = startY + game.selectedMenuIndex * (btnH + gap) + btnH / 2;
  game.menuHeroTargetX = lerp(baseHeroX, startX + btnW + 140, 0.35);
  game.menuHeroTargetY = lerp(baseHeroY, btnYPos, 0.45);

  game.menuHeroX = lerp(game.menuHeroX || baseHeroX, game.menuHeroTargetX, 0.08);
  game.menuHeroY = lerp(game.menuHeroY || baseHeroY, game.menuHeroTargetY, 0.08);

  for (let i = 0; i < menuBtns.length; i++) {
    let bx = startX;
    let by = startY + i * (btnH + gap);

    let isSelected = (game.selectedMenuIndex === i);
    let isMouseHover = mouseX >= bx && mouseX <= bx + btnW && mouseY >= by && mouseY <= by + btnH;

    if (isMouseHover) {
      game.selectedMenuIndex = i;
      isSelected = true;
    }

    stroke(isSelected ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(100));
    strokeWeight(isSelected ? 2 : 1);
    fill(isSelected ? color(theme.sidebar[0] + 15, theme.sidebar[1] + 15, theme.sidebar[2] + 25) : color(theme.panel[0], theme.panel[1], theme.panel[2], 220));
    rect(bx, by, btnW, btnH, 8);

    noStroke();
    fill(isSelected ? color(255) : color(200));
    textSize(13 * game.settings.uiScale);
    textStyle(BOLD);
    textAlign(LEFT, CENTER);
    text(menuBtns[i].label, bx + 20, by + btnH / 2);
  }

  let credW = 100 * game.settings.uiScale;
  let credH = 36 * game.settings.uiScale;
  let credX = startX;
  let credY = startY + menuBtns.length * (btnH + gap) + 10;
  let isCredHover = mouseX >= credX && mouseX <= credX + credW && mouseY >= credY && mouseY <= credY + credH;

  stroke(theme.accent[0], theme.accent[1], theme.accent[2]); strokeWeight(1); fill(isCredHover ? color(40, 60, 90) : color(20, 30, 45));
  rect(credX, credY, credW, credH, 6);
  noStroke(); fill(255); textSize(12 * game.settings.uiScale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("CREDITS", credX + credW / 2, credY + credH / 2);

  let exitW = 100 * game.settings.uiScale;
  let exitH = 36 * game.settings.uiScale;
  let exitX = startX + credW + 15;
  let exitY = credY;
  let isExitHover = mouseX >= exitX && mouseX <= exitX + exitW && mouseY >= exitY && mouseY <= exitY + exitH;

  stroke("coral"); strokeWeight(1); fill(isExitHover ? color(80, 20, 20) : color(40, 15, 15));
  rect(exitX, exitY, exitW, exitH, 6);
  noStroke(); fill(255); textSize(12 * game.settings.uiScale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("EXIT", exitX + exitW / 2, exitY + exitH / 2);

  drawBlueSun(game.menuHeroX, game.menuHeroY + floatOffset, 160);

  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(48 * game.settings.uiScale);
  fill(theme.accent[0], theme.accent[1], theme.accent[2], 60);
  text("PLANET CLICKER", game.menuHeroX, game.menuHeroY + floatOffset + 125);
  fill(255);
  text("PLANET CLICKER", game.menuHeroX, game.menuHeroY + floatOffset + 122);

  noStroke(); fill(180); textSize(14); textStyle(BOLD); textAlign(RIGHT, BOTTOM);
  text("Created by RivGS", width - 20, height - 15);

  if (game.activeOverlay) {
    drawOverlayWindow();
  }
}

function drawPauseMenu() {
  let theme = getTheme();
  fill(0, 0, 0, 180);
  rect(0, 0, width, height);

  textAlign(CENTER, CENTER);
  fill(theme.text[0], theme.text[1], theme.text[2]);
  textSize(42 * game.settings.uiScale);
  textStyle(BOLD);
  text("GAME PAUSED", width / 2, height * 0.24);

  let btnW = 220 * game.settings.uiScale;
  let btnH = 48 * game.settings.uiScale;
  let startY = height * 0.36;
  let gap = 16 * game.settings.uiScale;

  let pauseBtns = [
    { label: "RESUME", action: "RESUME" },
    { label: "ACHIEVEMENTS", action: "ACHIEVEMENTS" },
    { label: "OPTIONS", action: "SETTINGS" },
    { label: "HELP / INSTRUCTIONS", action: "HELP" },
    { label: "BACK TO MAIN MENU", action: "MAIN_MENU" }
  ];

  for (let i = 0; i < pauseBtns.length; i++) {
    let bx = width / 2 - btnW / 2;
    let by = startY + i * (btnH + gap);

    let isHover = mouseX >= bx && mouseX <= bx + btnW && mouseY >= by && mouseY <= by + btnH;
    stroke(theme.accent[0], theme.accent[1], theme.accent[2]);
    strokeWeight(isHover ? 2 : 1);
    fill(isHover ? color(theme.sidebar[0] + 15, theme.sidebar[1] + 15, theme.sidebar[2] + 25) : color(theme.panel[0], theme.panel[1], theme.panel[2]));
    rect(bx, by, btnW, btnH, 8);

    noStroke();
    fill(255);
    textSize(14 * game.settings.uiScale);
    textStyle(BOLD);
    text(pauseBtns[i].label, width / 2, by + btnH / 2);
  }

  if (game.activeOverlay) {
    drawOverlayWindow();
  }
}

function drawPauseButton() {
  if (game.shopOpen || game.planetSelectOpen) return;
  let theme = getTheme();

  let bx = 20;
  let by = height - 60;
  let bw = 130 * game.settings.uiScale;
  let bh = 40 * game.settings.uiScale;

  let isHover = mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh;
  stroke(theme.accent[0], theme.accent[1], theme.accent[2]);
  strokeWeight(1);
  fill(isHover ? color(theme.sidebar[0] + 15, theme.sidebar[1] + 15, theme.sidebar[2] + 25) : color(theme.panel[0], theme.panel[1], theme.panel[2]));
  rect(bx, by, bw, bh, 6);

  noStroke();
  fill(255);
  textSize(13 * game.settings.uiScale);
  textStyle(BOLD);
  textAlign(CENTER, CENTER);
  text(`Pause [${game.settings.keys.pause}]`, bx + bw / 2, by + bh / 2);
}

function drawOverlayWindow() {
  let theme = getTheme();
  fill(theme.panel[0], theme.panel[1], theme.panel[2], 250);
  stroke(theme.accent[0], theme.accent[1], theme.accent[2]);
  strokeWeight(2);

  let scale = game.settings.uiScale;
  let w = min(740 * scale, width - 40);
  let h = min(560 * scale, height - 40);
  let x = width / 2 - w / 2;
  let y = height / 2 - h / 2;

  rect(x, y, w, h, 12);

  noStroke();
  fill(theme.text[0], theme.text[1], theme.text[2]);
  textAlign(CENTER, TOP);
  textSize(22 * scale);
  textStyle(BOLD);

  if (game.activeOverlay === 'CREDITS') {
    text("GAME CREDITS", width / 2, y + 25 * scale);
    let startY = y + 65 * scale;
    let visibleH = h - 135 * scale;

    let creditsText = [
      { type: 'HEADER', text: 'CREATOR' },
      { type: 'NAME', text: 'RivGS' },
      { type: 'GAP' },
      { type: 'HEADER', text: 'DEVELOPERS (programmers)' },
      { type: 'NAME', text: 'RivGS' },
      { type: 'NAME', text: 'Courtney Ballard' },
      { type: 'GAP' },
      { type: 'HEADER', text: 'ART' },
      { type: 'NAME', text: 'Courtney Ballard' },
      { type: 'GAP' },
      { type: 'HEADER', text: 'AUDIO' },
      { type: 'NAME', text: 'Audio has not yet been added to this project' },
      { type: 'GAP' },
      { type: 'HEADER', text: 'NOTABLE PEOPLE' },
      { type: 'NAME', text: 'Noah Vega' },
      { type: 'NAME', text: 'Julien "Orteil" Thiennot' },
      { type: 'NAME', text: 'Coltroc' },
      { type: 'NAME', text: 'Everyone who played this game, Thank you everyone!' },
      { type: 'GAP' },
      { type: 'FOOTER', text: 'Code + Art assisted by Google Gemini' },
      { type: 'FOOTER', text: 'Programmed and ran on p5.js engine' }
    ];

    game.creditsContentHeight = creditsText.length * 32 * scale;

    if (game.isCreditsAutoScrolling) {
      if (game.creditsStartTimer < 120) {
        game.creditsStartTimer++;
      } else {
        game.creditsTargetScrollY += 0.35;
        let maxScroll = game.creditsContentHeight - visibleH + 40;
        if (game.creditsTargetScrollY > maxScroll) {
          game.creditsTargetScrollY = maxScroll;
        }
      }
    }

    game.creditsScrollY = lerp(game.creditsScrollY, game.creditsTargetScrollY, 0.25);

    let ctx = drawingContext; ctx.save(); ctx.beginPath();
    ctx.rect(x + 20, startY, w - 40, visibleH); ctx.clip();

    let curY = startY - game.creditsScrollY;
    for (let i = 0; i < creditsText.length; i++) {
      let item = creditsText[i];
      if (item.type === 'HEADER') {
        fill(theme.accent[0], theme.accent[1], theme.accent[2]);
        textSize(16 * scale); textStyle(BOLD); textAlign(CENTER, TOP);
        text(item.text, width / 2, curY);
        curY += 34 * scale;
      } else if (item.type === 'NAME') {
        fill(255); textSize(14 * scale); textStyle(NORMAL); textAlign(CENTER, TOP);
        text(item.text, width / 2, curY);
        curY += 26 * scale;
      } else if (item.type === 'FOOTER') {
        fill(180, 220, 255); textSize(12 * scale); textStyle(ITALIC); textAlign(CENTER, TOP);
        text(item.text, width / 2, curY);
        curY += 24 * scale;
      } else if (item.type === 'GAP') {
        curY += 22 * scale;
      }
    }
    ctx.restore();

  } else if (game.activeOverlay === 'LINKS') {
    text("COMMUNITY & LINKS", width / 2, y + 25 * scale);
    textAlign(CENTER, TOP); textSize(13 * scale); fill(200);
    text("Click any link below to visit official community pages:", width / 2, y + 65 * scale);

    let linkBtns = [
      { name: "YouTube Channel", icon: "▶", url: game.links.youtube, color: [255, 60, 60] },
      { name: "Discord Server", icon: "💬", url: game.links.discord, color: [114, 137, 218] },
      { name: "Report Bug / Feedback", icon: "📝", url: game.links.form, color: [40, 200, 120] } // New button
    ];

    let bw = 260 * scale; let bh = 55 * scale;
    for (let i = 0; i < linkBtns.length; i++) {
      let lb = linkBtns[i];
      let lx = width / 2 - bw / 2;
      let ly = y + 115 * scale + i * (bh + 20 * scale);

      let isHover = mouseX >= lx && mouseX <= lx + bw && mouseY >= ly && mouseY <= ly + bh;
      stroke(lb.color[0], lb.color[1], lb.color[2]); strokeWeight(isHover ? 2 : 1);
      fill(isHover ? color(lb.color[0] * 0.3, lb.color[1] * 0.3, lb.color[2] * 0.3, 200) : color(20, 25, 40));
      rect(lx, ly, bw, bh, 8);

      noStroke(); fill(255); textAlign(LEFT, CENTER);
      textSize(20 * scale); text(lb.icon, lx + 20 * scale, ly + bh / 2);
      textSize(15 * scale); textStyle(BOLD); text(lb.name, lx + 60 * scale, ly + bh / 2);
    }

  } else if (game.activeOverlay === 'ACHIEVEMENTS') {
    let unlockedCount = game.achievements.filter(a => a.unlocked).length;
    text(`ACHIEVEMENTS (${unlockedCount}/${game.achievements.length})`, width / 2, y + 25 * scale);

    let startY = y + 65 * scale;
    let visibleH = h - 130 * scale;
    let cardH = 46 * scale;
    let gapY = 8 * scale;
    game.achievementsContentHeight = game.achievements.length * (cardH + gapY);
    game.achievementsScrollY = lerp(game.achievementsScrollY, game.achievementsTargetScrollY, 0.25);

    let ctx = drawingContext; ctx.save(); ctx.beginPath();
    ctx.rect(x + 10, startY, w - 20, visibleH); ctx.clip();

    for (let i = 0; i < game.achievements.length; i++) {
      let ach = game.achievements[i];
      let cy = startY + i * (cardH + gapY) - game.achievementsScrollY;

      if (cy + cardH < startY || cy > startY + visibleH) continue;

      fill(ach.unlocked ? color(theme.sidebar[0] + 10, theme.sidebar[1] + 20, theme.sidebar[2] + 30) : color(theme.panel[0] - 5, theme.panel[1] - 5, theme.panel[2] - 5));
      stroke(ach.unlocked ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(60, 60, 80));
      strokeWeight(1);
      rect(x + 25 * scale, cy, w - 50 * scale, cardH, 6);

      noStroke(); textAlign(LEFT, CENTER);
      fill(ach.unlocked ? color(255, 215, 0) : color(140, 140, 160));
      textSize(14 * scale); textStyle(BOLD);
      text(ach.name, x + 38 * scale, cy + 15 * scale);

      fill(ach.unlocked ? color(200, 220, 250) : color(100, 100, 120));
      textSize(11 * scale); textStyle(NORMAL);
      text(ach.desc, x + 38 * scale, cy + 31 * scale);

      textAlign(RIGHT, CENTER);
      fill(ach.unlocked ? color(100, 255, 150) : color(120, 120, 140));
      textSize(12 * scale); textStyle(BOLD);
      text(ach.unlocked ? "UNLOCKED" : "LOCKED", x + w - 38 * scale, cy + 23 * scale);
    }
    ctx.restore();

  } else if (game.activeOverlay === 'SETTINGS') {
    text("OPTIONS & SETTINGS", width / 2, y + 20 * scale);
    textSize(11 * scale); fill(180); text("Use Q/E keys to switch tabs", width / 2, y + 42 * scale);

    let tabs = ['GENERAL', 'VIDEO', 'CONTROLS', 'GAMEPLAY', 'DATA'];
    let tabW = (w - 40 * scale) / tabs.length;
    let tabY = y + 60 * scale;

    for (let i = 0; i < tabs.length; i++) {
      let tx = x + 20 * scale + i * tabW;
      let isSel = (game.activeTab === tabs[i]);
      fill(isSel ? color(theme.accent[0], theme.accent[1], theme.accent[2], 80) : color(30, 30, 45));
      stroke(isSel ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(60));
      rect(tx, tabY, tabW - 4 * scale, 30 * scale, 4);

      noStroke(); fill(255); textSize(11 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
      text(tabs[i], tx + tabW / 2, tabY + 15 * scale);
    }

    let contentY = tabY + 45 * scale;

    if (game.activeTab === 'GENERAL') drawGeneralTab(x, contentY, w, scale);
    else if (game.activeTab === 'VIDEO') drawVideoTab(x, contentY, w, scale);
    else if (game.activeTab === 'CONTROLS') drawControlsTab(x, contentY, w, scale, h);
    else if (game.activeTab === 'GAMEPLAY') drawGameplayTab(x, contentY, w, scale);
    else if (game.activeTab === 'DATA') drawDataTab(x, contentY, w, scale);

    if (game.activeTab !== 'DATA') {
      let rW = 160 * scale; let rH = 32 * scale;
      let rX = x + 25 * scale; let rY = y + h - 55 * scale;
      stroke(120); fill(35, 35, 50); rect(rX, rY, rW, rH, 6);
      noStroke(); fill(255); textSize(11 * scale); textAlign(CENTER, CENTER);
      text("RESTORE TAB DEFAULTS", rX + rW / 2, rY + rH / 2);
    }

  } else if (game.activeOverlay === 'CUSTOMIZE_PLANET') {
    drawPlanetCustomizer(x, y, w, h, scale);
  } else if (game.activeOverlay === 'CONFIRM_DELETE') {
    text("DELETE SAVE CONFIRMATION", width / 2, y + 25 * scale);
    textAlign(CENTER, TOP); textSize(13 * scale); textStyle(NORMAL); fill(255, 120, 120);
    if (game.deleteWipesWizard) {
      text("WARNING: This erases ALL of your game data\nand returns you to the startup setup wizard window!", width / 2, y + 70 * scale);
    } else {
      text("WARNING: This will wipe clicks, upgrades,\nand planet progress back to standard new game state!", width / 2, y + 70 * scale);
    }
    fill(255); text("Type 'DELETE' below to confirm:", width / 2, y + 130 * scale);

    let inputW = 240 * scale; let inputH = 42 * scale;
    let inputX = width / 2 - inputW / 2; let inputY = y + 165 * scale;
    stroke(game.deleteInputActive ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(100));
    strokeWeight(2); fill(10, 10, 20); rect(inputX, inputY, inputW, inputH, 6);
    noStroke(); fill(255); textSize(18 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
    text(game.deleteInputText + (frameCount % 60 < 30 ? "|" : ""), width / 2, inputY + inputH / 2);

    let isMatch = game.deleteInputText.toUpperCase() === "DELETE";
    let confirmW = 200 * scale; let confirmH = 42 * scale;
    let confirmX = width / 2 - confirmW / 2; let confirmY = y + 235 * scale;
    stroke(isMatch ? "red" : 60); fill(isMatch ? color(120, 20, 20) : color(40));
    rect(confirmX, confirmY, confirmW, confirmH, 6);
    noStroke(); fill(isMatch ? 255 : 120); textSize(14 * scale);
    text("CONFIRM DELETION", width / 2, confirmY + confirmH / 2);
  } else if (game.activeOverlay === 'HELP') {
    text("HOW TO PLAY", width / 2, y + 25 * scale);
    textAlign(LEFT, TOP); textSize(13 * scale); textStyle(NORMAL); fill(200, 210, 230);
    let instructions = 
      "• Click the central planet or press Spacebar to gain Clicks.\n\n" +
      "• Open Upgrades [U] to buy CPS generators & multipliers.\n\n" +
      "• Perform Rebirths when reaching target clicks to permanently boost multiplier by +10% per rebirth!\n\n" +
      "• Unlock new Celestial Systems in Planets [P] for exclusive upgrades & customizer settings!\n\n" +
      "• Click Golden Comets or Void Asteroids for massive bonuses!\n\n" +
      "• Complete 30 cosmic Achievements and customize full Video/Control Options.";
    text(instructions, x + 35 * scale, y + 75 * scale, w - 70 * scale, h - 140 * scale);
  }

  let closeW = 100 * scale; let closeH = 38 * scale;
  let closeX = x + w - closeW - 25 * scale; let closeY = y + h - 55 * scale;
  stroke("coral"); strokeWeight(1); fill(color(40, 20, 20));
  rect(closeX, closeY, closeW, closeH, 6);
  noStroke(); fill(255); textSize(13 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("CLOSE", closeX + closeW / 2, closeY + closeH / 2);
}

function drawGeneralTab(x, y, w, scale) {
  let theme = getTheme();
  textSize(14 * scale); textAlign(LEFT, CENTER); fill(255);
  text("Sound Effects (SFX)", x + 35 * scale, y + 20 * scale);
  text("Background Music", x + 35 * scale, y + 70 * scale);

  let toggleW = 80 * scale; let toggleH = 32 * scale;
  fill(game.settings.sfxEnabled ? color(40, 180, 100) : color(80));
  rect(x + w - 120 * scale, y + 5 * scale, toggleW, toggleH, 6);
  fill(255); textAlign(CENTER, CENTER);
  text(game.settings.sfxEnabled ? "ON" : "OFF", x + w - 120 * scale + toggleW / 2, y + 5 * scale + toggleH / 2);

  fill(game.settings.musicEnabled ? color(40, 180, 100) : color(80));
  rect(x + w - 120 * scale, y + 55 * scale, toggleW, toggleH, 6);
  fill(255);
  text(game.settings.musicEnabled ? "ON" : "OFF", x + w - 120 * scale + toggleW / 2, y + 55 * scale + toggleH / 2);
}

function drawVideoTab(x, y, w, scale) {
  let theme = getTheme();
  textSize(13 * scale); textAlign(LEFT, CENTER); fill(255);
  text("Theme Preset", x + 35 * scale, y + 15 * scale);
  let themeNames = ['Dark', 'Xtra Dark', 'Contrast', 'Color Blind', 'Light Mode'];
  for (let i = 0; i < themeNames.length; i++) {
    let tx = x + 35 * scale + (i % 3) * 115 * scale;
    let ty = y + 32 * scale + Math.floor(i / 3) * 32 * scale;
    let isSel = (game.settings.currentTheme === themeNames[i]);
    fill(isSel ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(40));
    rect(tx, ty, 105 * scale, 26 * scale, 4);
    fill(255); textAlign(CENTER, CENTER); textSize(10 * scale);
    text(themeNames[i], tx + 52 * scale, ty + 13 * scale);
  }

  textSize(13 * scale); textAlign(LEFT, CENTER); fill(255);
  text("Accent Color", x + 35 * scale, y + 105 * scale);
  for (let i = 0; i < ACCENT_PRESETS.length; i++) {
    let ax = x + 150 * scale + i * 35 * scale;
    fill(ACCENT_PRESETS[i]); stroke(game.settings.accentColor === ACCENT_PRESETS[i] ? 255 : 0);
    strokeWeight(2); circle(ax, y + 105 * scale, 20 * scale);
  }

  textAlign(LEFT, CENTER); textSize(12 * scale); fill(255);
  text(`Stars Enabled`, x + 35 * scale, y + 145 * scale);
  fill(game.settings.starsEnabled ? color(40, 180, 100) : color(80));
  rect(x + 150 * scale, y + 133 * scale, 65 * scale, 24 * scale, 4);
  fill(255); textAlign(CENTER, CENTER); text(game.settings.starsEnabled ? "ON" : "OFF", x + 182 * scale, y + 145 * scale);

  textAlign(LEFT, CENTER);
  text(`FPS Counter`, x + 240 * scale, y + 145 * scale);
  fill(game.settings.showFPS ? color(40, 180, 100) : color(80));
  rect(x + 330 * scale, y + 133 * scale, 65 * scale, 24 * scale, 4);
  fill(255); textAlign(CENTER, CENTER); text(game.settings.showFPS ? "ON" : "OFF", x + 362 * scale, y + 145 * scale);

  textAlign(LEFT, CENTER);
  text(`Target FPS: ${game.settings.targetFPS}`, x + 420 * scale, y + 145 * scale);
  let fpsOpts = [30, 60, 120];
  for (let i = 0; i < fpsOpts.length; i++) {
    let fx = x + 535 * scale + i * 40 * scale;
    let isSel = game.settings.targetFPS === fpsOpts[i];
    fill(isSel ? color(theme.accent[0], theme.accent[1], theme.accent[2]) : color(40));
    rect(fx, y + 133 * scale, 35 * scale, 24 * scale, 4);
    fill(255); textAlign(CENTER, CENTER); textSize(10 * scale); text(fpsOpts[i], fx + 17 * scale, y + 145 * scale);
  }

  textAlign(LEFT, CENTER); textSize(12 * scale); fill(255);
  text(`Star Density: ${game.settings.starCount}`, x + 35 * scale, y + 185 * scale);
  stroke(100); line(x + 160 * scale, y + 185 * scale, x + 300 * scale, y + 185 * scale);
  let starHandle = map(game.settings.starCount, 40, 300, x + 160 * scale, x + 300 * scale);
  fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(starHandle, y + 185 * scale, 14 * scale);

  fill(255); textAlign(LEFT, CENTER);
  text("Star Speed Preview:", x + 340 * scale, y + 185 * scale);
  let pX = x + 470 * scale; let pY = y + 185 * scale;
  let pSize = 3 + sin(frameCount * 0.1 * game.settings.starSpeed) * 1.5;
  fill(255); circle(pX, pY, pSize);

  text(`UI Scaling: ${(game.settings.uiScale * 100).toFixed(0)}%`, x + 35 * scale, y + 225 * scale);
  stroke(100); line(x + 160 * scale, y + 225 * scale, x + 300 * scale, y + 225 * scale);
  let uiHandle = map(game.settings.uiScale, 0.8, 1.4, x + 160 * scale, x + 300 * scale);
  fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(uiHandle, y + 225 * scale, 14 * scale);

  fill(255);
  text(`Brightness: ${(game.settings.brightness * 100).toFixed(0)}%`, x + 35 * scale, y + 265 * scale);
  stroke(100); line(x + 160 * scale, y + 265 * scale, x + 300 * scale, y + 265 * scale);
  let brightHandle = map(game.settings.brightness, 0.5, 1.5, x + 160 * scale, x + 300 * scale);
  fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(brightHandle, y + 265 * scale, 14 * scale);

  fill(255);
  text("Fullscreen", x + 340 * scale, y + 265 * scale);
  fill(game.settings.fullscreen ? color(40, 180, 100) : color(80));
  rect(x + 420 * scale, y + 251 * scale, 70 * scale, 26 * scale, 4);
  fill(255); textAlign(CENTER, CENTER);
  text(game.settings.fullscreen ? "ON" : "OFF", x + 455 * scale, y + 265 * scale);
}

function drawControlsTab(x, y, w, scale, h) {
  let theme = getTheme();
  textSize(12 * scale); textAlign(LEFT, CENTER); fill(255);

  let keyList = [
    { label: "Toggle Shop", id: "shop" },
    { label: "Toggle Planets", id: "planets" },
    { label: "Pause Game", id: "pause" },
    { label: "Click Planet", id: "click" }
  ];

  game.upgrades.forEach(u => {
    keyList.push({ label: `Upgrade [${u.id}] ${u.name}`, id: `upg_${u.id}` });
  });

  let cols = 2;
  let colW = (w - 70 * scale) / cols;

  for (let i = 0; i < keyList.length; i++) {
    let col = i % cols;
    let row = Math.floor(i / cols);
    let kx = x + 30 * scale + col * colW;
    let ky = y + 15 * scale + row * 28 * scale;

    let truncatedLabel = keyList[i].label;
    if (truncatedLabel.length > 24) {
      truncatedLabel = truncatedLabel.substring(0, 22) + '...';
    }

    text(truncatedLabel, kx, ky);

    let isRemapping = (game.remappingKeyId === keyList[i].id);
    fill(isRemapping ? color(255, 140, 0) : color(40, 50, 70));
    stroke(theme.accent[0], theme.accent[1], theme.accent[2]);
    rect(kx + colW - 70 * scale, ky - 10 * scale, 65 * scale, 20 * scale, 4);

    noStroke(); fill(255); textAlign(CENTER, CENTER); textSize(10 * scale);
    text(isRemapping ? "PRESS..." : (game.settings.keys[keyList[i].id] || 'NONE'), kx + colW - 37 * scale, ky);
  }
}

function drawGameplayTab(x, y, w, scale) {
  textSize(13 * scale); textAlign(LEFT, CENTER); fill(255);
  text("Spacebar Clicker Input", x + 40 * scale, y + 30 * scale);

  let toggleW = 80 * scale; let toggleH = 32 * scale;
  fill(game.settings.spacebarClicking ? color(40, 180, 100) : color(80));
  rect(x + w - 130 * scale, y + 14 * scale, toggleW, toggleH, 6);
  fill(255); textAlign(CENTER, CENTER);
  text(game.settings.spacebarClicking ? "ON" : "OFF", x + w - 130 * scale + toggleW / 2, y + 14 * scale + toggleH / 2);
}

function drawDataTab(x, y, w, scale) {
  let theme = getTheme();
  textSize(14 * scale); textAlign(CENTER, TOP); fill(255, 120, 120);
  text("PERMANENT SAVE DATA & SETTINGS MANAGEMENT", width / 2, y + 15 * scale);

  let rW = 240 * scale; let rH = 38 * scale;
  let rX = width / 2 - rW / 2; let rY = y + 55 * scale;
  stroke(theme.accent[0], theme.accent[1], theme.accent[2]); fill(25, 40, 60); rect(rX, rY, rW, rH, 6);
  noStroke(); fill(255); textSize(12 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("RESTORE ALL TAB DEFAULTS", width / 2, rY + rH / 2);

  let delW = 240 * scale; let delH = 38 * scale;
  let delX = width / 2 - delW / 2; let delY = y + 105 * scale;
  stroke("orange"); fill(60, 30, 15); rect(delX, delY, delW, delH, 6);
  noStroke(); fill(255); textSize(12 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("RESET GAME PROGRESS...", width / 2, delY + delH / 2);

  let fullW = 260 * scale; let fullH = 42 * scale;
  let fullX = width / 2 - fullW / 2; let fullY = y + 160 * scale;
  stroke("red"); fill(90, 15, 15); rect(fullX, fullY, fullW, fullH, 6);
  noStroke(); fill(255); textSize(13 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("DELETE ALL DATA", width / 2, fullY + fullH / 2);

  textSize(11 * scale); fill(180); textAlign(CENTER, TOP);
  text("Note: 'DELETE ALL DATA' returns you to startup window.", width / 2, fullY + fullH + 10 * scale);
}

function drawPlanetCustomizer(x, y, w, h, scale) {
  let theme = getTheme();
  let planet = game.planets[game.activePlanetIndex];
  textAlign(CENTER, TOP); textSize(18 * scale); textStyle(BOLD); fill(255);
  text(`CUSTOMIZE ${planet.name.toUpperCase()}`, width / 2, y + 20 * scale);

  push(); translate(width / 2, y + 110 * scale);
  drawActivePlanet(0, 0, 90 * scale);
  pop();

  let cy = y + 170 * scale;
  textAlign(LEFT, CENTER); textSize(13 * scale); fill(200);
  text("Primary Color:", x + 40 * scale, cy);
  let pColors = ['#00dcff', '#ff461e', '#a05af0', '#28e678', '#ffd700', '#ff78b4', '#ffffff'];
  for (let i = 0; i < pColors.length; i++) {
    let bx = x + 180 * scale + i * 38 * scale;
    fill(pColors[i]); stroke(planet.primaryColor === pColors[i] ? 255 : 0);
    strokeWeight(2); circle(bx, cy, 22 * scale);
  }

  cy += 45 * scale;
  text("Secondary Color:", x + 40 * scale, cy);
  let sColors = ['#008cff', '#ff7800', '#c8a0ff', '#009650', '#ff9000', '#b42878', '#5064ff'];
  for (let i = 0; i < sColors.length; i++) {
    let bx = x + 180 * scale + i * 38 * scale;
    fill(sColors[i]); stroke(planet.secondaryColor === sColors[i] ? 255 : 0);
    strokeWeight(2); circle(bx, cy, 22 * scale);
  }

  cy += 45 * scale;
  text("Outline Color:", x + 40 * scale, cy);
  let oColors = ['#ffffff', '#00ffff', '#ff00ff', '#ffff00', '#00ff00', '#ff0000', '#a05af0'];
  for (let i = 0; i < oColors.length; i++) {
    let bx = x + 180 * scale + i * 38 * scale;
    fill(oColors[i]); stroke(planet.outlineColor === oColors[i] ? 255 : 0);
    strokeWeight(2); circle(bx, cy, 22 * scale);
  }

  cy += 45 * scale;
  text(`Animation Speed: ${planet.speedScale.toFixed(1)}x`, x + 40 * scale, cy);
  stroke(100); line(x + 220 * scale, cy, x + 380 * scale, cy);
  let spdHandle = map(planet.speedScale, 0.2, 3.0, x + 220 * scale, x + 380 * scale);
  fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(spdHandle, cy, 14 * scale);

  cy += 45 * scale; fill(200);
  text(`Particle Density: ${planet.particleDensity.toFixed(1)}x`, x + 40 * scale, cy);
  stroke(100); line(x + 220 * scale, cy, x + 380 * scale, cy);
  let denHandle = map(planet.particleDensity, 0.2, 3.0, x + 220 * scale, x + 380 * scale);
  fill(theme.accent[0], theme.accent[1], theme.accent[2]); noStroke(); circle(denHandle, cy, 14 * scale);
}

function updateAsteroids() {
  let ast = game.asteroid;
  if (!ast.active) {
    ast.spawnTimer++;
    if (ast.spawnTimer > random(800, 1400)) {
      ast.active = true; ast.spawnTimer = 0;
      let startFromLeft = random() > 0.5;
      ast.x = startFromLeft ? -40 : width + 40;
      ast.y = random(100, height - 100);
      ast.vx = startFromLeft ? random(3, 5.5) : random(-5.5, -3);
      ast.vy = random(-1.5, 1.5);
    }
  } else {
    ast.x += ast.vx; ast.y += ast.vy;
    if (frameCount % 2 === 0) game.particles.push(new Particle(ast.x, ast.y, [255, 215, 0]));
    if (ast.x < -80 || ast.x > width + 80 || ast.y < -80 || ast.y > height + 80) ast.active = false;
  }

  let dark = game.darkAsteroid;
  if (!dark.active) {
    dark.spawnTimer++;
    if (dark.spawnTimer > random(1500, 2500)) {
      dark.active = true; dark.spawnTimer = 0;
      let startFromLeft = random() > 0.5;
      dark.x = startFromLeft ? -40 : width + 40;
      dark.y = random(100, height - 100);
      dark.vx = startFromLeft ? random(4, 7) : random(-7, -4);
      dark.vy = random(-2, 2);
    }
  } else {
    dark.x += dark.vx; dark.y += dark.vy;
    if (frameCount % 2 === 0) game.particles.push(new Particle(dark.x, dark.y, [180, 50, 255]));
    if (dark.x < -80 || dark.x > width + 80 || dark.y < -80 || dark.y > height + 80) dark.active = false;
  }
}

function drawAsteroids() {
  let ast = game.asteroid;
  if (ast.active) {
    push(); translate(ast.x, ast.y); noStroke();
    fill(255, 120, 0, 80 + sin(frameCount * 0.1) * 30); circle(0, 0, ast.size + 20);
    fill(255, 200, 50); circle(0, 0, ast.size);
    fill(255, 240, 150); circle(-5, -5, ast.size * 0.5); pop();
  }

  let dark = game.darkAsteroid;
  if (dark.active) {
    push(); translate(dark.x, dark.y); noStroke();
    fill(140, 0, 220, 90 + sin(frameCount * 0.12) * 40); circle(0, 0, dark.size + 24);
    fill(40, 10, 60); circle(0, 0, dark.size);
    fill(180, 80, 255); circle(-4, -4, dark.size * 0.45); pop();
  }
}

function drawActivePlanet(cx, cy, diameter) {
  let planet = game.planets[game.activePlanetIndex];
  
  if (planet.id === 'sun') drawBlueSun(cx, cy, diameter);
  else if (planet.id === 'pyronis') drawPyronis(cx, cy, diameter);
  else if (planet.id === 'zephyrus') drawZephyrus(cx, cy, diameter);
  else if (planet.id === 'virelia') drawVirelia(cx, cy, diameter);
  else if (planet.id === 'oblivion') drawOblivion(cx, cy, diameter);
  else if (planet.id === 'aethelgard') drawAethelgard(cx, cy, diameter);
  else if (planet.id === 'glacies') drawGlacies(cx, cy, diameter);
  else if (planet.id === 'chronos') drawChronos(cx, cy, diameter);
  else if (planet.id === 'nebula') drawNebula(cx, cy, diameter);
  else if (planet.id === 'solaris') drawSolaris(cx, cy, diameter);
  else if (planet.id === 'toxica') drawToxica(cx, cy, diameter);
  else if (planet.id === 'abyss') drawAbyss(cx, cy, diameter);
  else drawGenericPlanet(cx, cy, diameter, planet);
}

function drawBlueSun(cx, cy, diameter) {
  let planet = game.planets[0];
  let pCol = hexToRgb(planet.primaryColor);
  let sCol = hexToRgb(planet.secondaryColor);
  let oCol = hexToRgb(planet.outlineColor || '#ffffff');
  let spd = planet.speedScale;

  push(); noStroke();
  fill(pCol[0], pCol[1], pCol[2], 20 + sin(frameCount * 0.04 * spd) * 8);
  circle(cx, cy, diameter + 80);
  fill(pCol[0], pCol[1], pCol[2], 40);
  circle(cx, cy, diameter + 42);

  let rays = 12;
  push(); translate(cx, cy); rotate(frameCount * 0.005 * spd);
  for (let i = 0; i < rays; i++) {
    rotate(TWO_PI / rays);
    let rayLength = (diameter / 2) + 20 + sin(frameCount * 0.08 * spd + i) * 12;
    fill(pCol[0], pCol[1], pCol[2], 45);
    triangle(-10, 0, 10, 0, 0, rayLength);
  }
  pop();

  stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(sCol[0], sCol[1], sCol[2]); circle(cx, cy, diameter);
  noStroke(); fill(pCol[0], pCol[1], pCol[2]); circle(cx, cy, diameter * 0.85);
  fill(230, 250, 255); circle(cx, cy, diameter * 0.45);
  pop();
}

function drawPyronis(cx, cy, diameter) {
  let planet = game.planets[1];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 35 + sin(frameCount * 0.08 * planet.speedScale) * 15);
  circle(cx, cy, diameter + 35);
  fill(50, 15, 10); circle(cx, cy, diameter);

  let ctx = drawingContext; ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, diameter / 2, 0, Math.PI * 2); ctx.clip();
  stroke(pCol[0], pCol[1], pCol[2]); strokeWeight(5);
  for (let i = 0; i < 5; i++) {
    let offset = sin(frameCount * 0.03 * planet.speedScale + i) * 12;
    line(cx - diameter * 0.4, cy - 40 + i * 25 + offset, cx + diameter * 0.4, cy - 30 + i * 25 - offset);
  }
  ctx.restore(); pop();
}

function drawZephyrus(cx, cy, diameter) {
  let planet = game.planets[2];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 100);
  ellipse(cx, cy, diameter * 1.65, diameter * 0.42);
  fill(100, 40, 180); circle(cx, cy, diameter);
  noFill(); stroke(pCol[0], pCol[1], pCol[2], 180); strokeWeight(7);
  arc(cx, cy, diameter * 1.65, diameter * 0.42, 0, PI); pop();
}

function drawVirelia(cx, cy, diameter) {
  let planet = game.planets[3];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 25 + sin(frameCount * 0.03 * planet.speedScale) * 10);
  circle(cx, cy, diameter + 45);
  fill(10, 60, 40); circle(cx, cy, diameter);
  pop();
}

function drawOblivion(cx, cy, diameter) {
  let planet = game.planets[4];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 40); circle(cx, cy, diameter + 50);
  fill(15, 5, 25); circle(cx, cy, diameter); pop();
}

function drawAethelgard(cx, cy, diameter) {
  let planet = game.planets[5];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 35); circle(cx, cy, diameter + 60);
  fill(255, 230, 120); circle(cx, cy, diameter); pop();
}

function drawGlacies(cx, cy, diameter) {
  let planet = game.planets[6];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 40); circle(cx, cy, diameter + 45);
  fill(200, 240, 255); circle(cx, cy, diameter); pop();
}

function drawChronos(cx, cy, diameter) {
  let planet = game.planets[7];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 40); circle(cx, cy, diameter + 55);
  fill(70, 20, 50); circle(cx, cy, diameter); pop();
}

function drawNebula(cx, cy, diameter) {
  let planet = game.planets[8];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 45); circle(cx, cy, diameter + 60);
  fill(120, 30, 100); circle(cx, cy, diameter); pop();
}

function drawSolaris(cx, cy, diameter) {
  let planet = game.planets[9];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 50); circle(cx, cy, diameter + 65);
  fill(255, 160, 40); circle(cx, cy, diameter); pop();
}

function drawToxica(cx, cy, diameter) {
  let planet = game.planets[10];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 40); circle(cx, cy, diameter + 50);
  fill(30, 70, 20); circle(cx, cy, diameter); pop();
}

function drawAbyss(cx, cy, diameter) {
  let planet = game.planets[11];
  let pCol = hexToRgb(planet.primaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 45); circle(cx, cy, diameter + 55);
  fill(10, 15, 45); circle(cx, cy, diameter); pop();
}

function drawGenericPlanet(cx, cy, diameter, planet) {
  let pCol = hexToRgb(planet.primaryColor);
  let sCol = hexToRgb(planet.secondaryColor);
  let oCol = hexToRgb(planet.outlineColor);
  push(); stroke(oCol[0], oCol[1], oCol[2], 180); strokeWeight(2);
  fill(pCol[0], pCol[1], pCol[2], 40); circle(cx, cy, diameter + 50);
  fill(sCol[0], sCol[1], sCol[2]); circle(cx, cy, diameter);
  fill(pCol[0], pCol[1], pCol[2], 180); circle(cx, cy, diameter * 0.7); pop();
}

function drawPlanetSelectOverlay() {
  let theme = getTheme();
  let scale = game.settings.uiScale;
  push(); translate(0, game.planetMenuY);

  fill(theme.bg[0], theme.bg[1], theme.bg[2], 245); rect(0, 0, width, height);
  textAlign(CENTER, TOP); fill(theme.text[0], theme.text[1], theme.text[2]);
  textSize(26 * scale); textStyle(BOLD); text("PLANETARY SYSTEM SELECT", width / 2, 25 * scale);

  let cols = 4;
  let cardWidth = 140 * scale; let cardHeight = 175 * scale;
  let gapX = 25 * scale; let gapY = 25 * scale;
  let startX = (width - (cols * cardWidth + (cols - 1) * gapX)) / 2;
  let startY = 75 * scale;
  
  let rows = Math.ceil(game.planets.length / cols);
  game.planetContentHeight = rows * (cardHeight + gapY);
  game.planetScrollY = lerp(game.planetScrollY, game.planetTargetScrollY, 0.25);

  let ctx = drawingContext; ctx.save(); ctx.beginPath();
  ctx.rect(0, startY, width, height - startY - 80 * scale); ctx.clip();

  for (let i = 0; i < game.planets.length; i++) {
    let p = game.planets[i];
    let col = i % cols; let row = Math.floor(i / cols);
    let px = startX + col * (cardWidth + gapX);
    let py = startY + row * (cardHeight + gapY) - game.planetScrollY;

    if (py + cardHeight < startY || py > height - 80 * scale) continue;

    let relMouseY = mouseY - game.planetMenuY;
    let isHovered = mouseX >= px && mouseX <= px + cardWidth && relMouseY >= py && relMouseY <= py + cardHeight && relMouseY >= startY && relMouseY <= height - 80 * scale;

    stroke(p.unlocked ? p.color[0] : 60, p.unlocked ? p.color[1] : 60, p.unlocked ? p.color[2] : 60);
    strokeWeight(isHovered ? 2.5 : 1);
    fill(isHovered ? color(theme.sidebar[0] + 10, theme.sidebar[1] + 10, theme.sidebar[2] + 15) : color(theme.panel[0], theme.panel[1], theme.panel[2]));
    rect(px, py, cardWidth, cardHeight, 10);

    push(); translate(px + cardWidth / 2, py + 44 * scale);
    fill(p.unlocked ? p.color : [70, 70, 80]); noStroke(); circle(0, 0, 40 * scale); pop();

    textAlign(CENTER, CENTER); noStroke(); fill(255); textSize(13 * scale); textStyle(BOLD);
    text(p.name, px + cardWidth / 2, py + 84 * scale);

    if (p.unlocked) {
      if (game.activePlanetIndex === i) {
        fill(100, 255, 150); textSize(11 * scale); text("ACTIVE", px + cardWidth / 2, py + 115 * scale);
      } else {
        fill(180, 180, 210); textSize(11 * scale); text("EQUIP", px + cardWidth / 2, py + 115 * scale);
      }

      let custW = 90 * scale; let custH = 24 * scale;
      let custX = px + cardWidth / 2 - custW / 2; let custY = py + 138 * scale;
      let isCustHover = mouseX >= custX && mouseX <= custX + custW && relMouseY >= custY && relMouseY <= custY + custH;
      
      stroke(isCustHover ? 255 : color(theme.accent[0], theme.accent[1], theme.accent[2]));
      strokeWeight(isCustHover ? 2 : 1);
      fill(isCustHover ? color(40, 70, 110) : color(20, 35, 55));
      rect(custX, custY, custW, custH, 4);
      noStroke(); fill(255); textSize(10 * scale); text("CUSTOMIZE", custX + custW / 2, custY + custH / 2);
    } else {
      let canAfford = game.clicks >= p.cost;
      fill(canAfford ? color(255, 200, 80) : color(230, 90, 100));
      textSize(10 * scale); text(`Unlock:\n¤ ${formatCost(p.cost)}`, px + cardWidth / 2, py + 125 * scale);
    }
  }

  ctx.restore();

  let closeY = height - 65 * scale;
  fill(theme.bg[0], theme.bg[1], theme.bg[2]); noStroke(); rect(0, closeY - 10, width, 75);
  stroke("coral"); strokeWeight(1); fill(color(40, 20, 20));
  rect(width / 2 - 50 * scale, closeY, 100 * scale, 40 * scale, 8);
  noStroke(); fill(255); textSize(13 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("CLOSE", width / 2, closeY + 20 * scale); pop();
}

function formatCost(cost) {
  if (cost >= 1000000000000000) return (cost / 1000000000000000).toFixed(1) + 'Q';
  if (cost >= 1000000000000) return (cost / 1000000000000).toFixed(1) + 'T';
  if (cost >= 1000000000) return (cost / 1000000000).toFixed(1) + 'B';
  if (cost >= 1000000) return (cost / 1000000).toFixed(1) + 'M';
  if (cost >= 1000) return (cost / 1000).toFixed(0) + 'K';
  return cost.toLocaleString();
}

function drawTopNavButtons() {
  if (game.shopOpen) return;
  let theme = getTheme();
  let scale = game.settings.uiScale;

  let pBtnHover = mouseX >= 20 && mouseX <= 140 * scale && mouseY >= 20 && mouseY <= 60 * scale;
  stroke(theme.accent[0], theme.accent[1], theme.accent[2]); strokeWeight(1);
  fill(pBtnHover ? color(theme.sidebar[0] + 15, theme.sidebar[1] + 15, theme.sidebar[2] + 25) : color(theme.panel[0], theme.panel[1], theme.panel[2]));
  rect(20, 20, 130 * scale, 40 * scale, 6);

  noStroke(); fill(255); textSize(13 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text(`Planets [${game.settings.keys.planets}]`, 20 + (130 * scale) / 2, 20 + (40 * scale) / 2);

  drawShopToggleButton();
}

function mousePressed() {
  if (game.gameState === 'SETUP_WIZARD') {
    let btnW = 180; let btnH = 45;
    let btnX = width / 2 - btnW / 2; let btnY = height - 70;
    if (mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH) {
      if (game.setupStep === 0) game.setupStep = 1;
      else { game.gameState = 'MAIN_MENU'; saveGame(); }
      return;
    }

    if (game.setupStep === 0) {
      let sliderX = width / 2 - 120; let sliderY = 320;
      if (mouseX >= sliderX - 20 && mouseX <= sliderX + 260 && mouseY >= sliderY - 20 && mouseY <= sliderY + 20) {
        game.settings.brightness = constrain(map(mouseX, sliderX, sliderX + 240, 0.5, 1.5), 0.5, 1.5);
      }
    } else if (game.setupStep === 1) {
      let sliderX = width / 2 - 120; let sliderY = 320;
      if (mouseX >= sliderX - 20 && mouseX <= sliderX + 260 && mouseY >= sliderY - 20 && mouseY <= sliderY + 20) {
        game.settings.uiScale = constrain(map(mouseX, sliderX, sliderX + 240, 0.8, 1.4), 0.8, 1.4);
      }

      let themeNames = ['Dark', 'Xtra Dark', 'Contrast', 'Color Blind', 'Light Mode'];
      for (let i = 0; i < themeNames.length; i++) {
        let tx = width / 2 - 225 + i * 92; let ty = 410;
        if (mouseX >= tx && mouseX <= tx + 85 && mouseY >= ty && mouseY <= ty + 26) {
          game.settings.currentTheme = themeNames[i];
          return;
        }
      }

      for (let i = 0; i < ACCENT_PRESETS.length; i++) {
        let ax = width / 2 - 140 + i * 40; let ay = 480;
        if (dist(mouseX, mouseY, ax, ay) < 15) {
          game.settings.accentColor = ACCENT_PRESETS[i];
          return;
        }
      }
    }
    return;
  }

  if (game.activeOverlay) {
    let scale = game.settings.uiScale;
    let w = min(740 * scale, width - 40);
    let h = min(560 * scale, height - 40);
    let x = width / 2 - w / 2;
    let y = height / 2 - h / 2;

    if (game.activeOverlay === 'CREDITS') {
      game.isCreditsAutoScrolling = false;
    }

if (game.activeOverlay === 'LINKS') {
      let bw = 260 * scale; let bh = 55 * scale;
      let linkBtns = [
        { url: game.links.youtube },
        { url: game.links.discord },
        { url: game.links.form }
      ];

      for (let i = 0; i < linkBtns.length; i++) {
        let lx = width / 2 - bw / 2;
        let ly = y + 115 * scale + i * (bh + 20 * scale);
        if (mouseX >= lx && mouseX <= lx + bw && mouseY >= ly && mouseY <= ly + bh) {
          window.open(linkBtns[i].url, '_blank');
          return;
        }
      }
    }

    if (game.activeOverlay === 'CONFIRM_DELETE') {
      let inputW = 240 * scale; let inputH = 42 * scale;
      let inputX = width / 2 - inputW / 2; let inputY = y + 165 * scale;
      game.deleteInputActive = (mouseX >= inputX && mouseX <= inputX + inputW && mouseY >= inputY && mouseY <= inputY + inputH);

      let confirmW = 200 * scale; let confirmH = 42 * scale;
      let confirmX = width / 2 - confirmW / 2; let confirmY = y + 235 * scale;
      let isMatch = game.deleteInputText.toUpperCase() === "DELETE";

      if (isMatch && mouseX >= confirmX && mouseX <= confirmX + confirmW && mouseY >= confirmY && mouseY <= confirmY + confirmH) {
        deleteSaveData();
        game.activeOverlay = null;
        if (game.deleteWipesWizard) {
          game.gameState = 'SETUP_WIZARD';
          game.setupStep = 0;
        } else {
          game.gameState = 'MAIN_MENU';
        }
        return;
      }
    }

    if (game.activeOverlay === 'CUSTOMIZE_PLANET') {
      let planet = game.planets[game.activePlanetIndex];
      let cy = y + 170 * scale;
      let pColors = ['#00dcff', '#ff461e', '#a05af0', '#28e678', '#ffd700', '#ff78b4', '#ffffff'];
      for (let i = 0; i < pColors.length; i++) {
        let bx = x + 180 * scale + i * 38 * scale;
        if (dist(mouseX, mouseY, bx, cy) < 15 * scale) { planet.primaryColor = pColors[i]; planet.color = hexToRgb(pColors[i]); saveGame(); }
      }

      cy += 45 * scale;
      let sColors = ['#008cff', '#ff7800', '#c8a0ff', '#009650', '#ff9000', '#b42878', '#5064ff'];
      for (let i = 0; i < sColors.length; i++) {
        let bx = x + 180 * scale + i * 38 * scale;
        if (dist(mouseX, mouseY, bx, cy) < 15 * scale) { planet.secondaryColor = sColors[i]; saveGame(); }
      }

      cy += 45 * scale;
      let oColors = ['#ffffff', '#00ffff', '#ff00ff', '#ffff00', '#00ff00', '#ff0000', '#a05af0'];
      for (let i = 0; i < oColors.length; i++) {
        let bx = x + 180 * scale + i * 38 * scale;
        if (dist(mouseX, mouseY, bx, cy) < 15 * scale) { planet.outlineColor = oColors[i]; saveGame(); }
      }
    }

    if (game.activeOverlay === 'SETTINGS') {
      let tabs = ['GENERAL', 'VIDEO', 'CONTROLS', 'GAMEPLAY', 'DATA'];
      let tabW = (w - 40 * scale) / tabs.length;
      let tabY = y + 60 * scale;

      for (let i = 0; i < tabs.length; i++) {
        let tx = x + 20 * scale + i * tabW;
        if (mouseX >= tx && mouseX <= tx + tabW && mouseY >= tabY && mouseY <= tabY + 30 * scale) {
          game.activeTab = tabs[i];
          return;
        }
      }

      let contentY = tabY + 45 * scale;
      let toggleW = 80 * scale; let toggleH = 32 * scale;

      if (game.activeTab === 'GENERAL') {
        if (mouseX >= x + w - 120 * scale && mouseX <= x + w - 120 * scale + toggleW && mouseY >= contentY + 5 * scale && mouseY <= contentY + 5 * scale + toggleH) {
          game.settings.sfxEnabled = !game.settings.sfxEnabled; saveGame(); return;
        }
        if (mouseX >= x + w - 120 * scale && mouseX <= x + w - 120 * scale + toggleW && mouseY >= contentY + 55 * scale && mouseY <= contentY + 55 * scale + toggleH) {
          game.settings.musicEnabled = !game.settings.musicEnabled; saveGame(); return;
        }
      } else if (game.activeTab === 'VIDEO') {
        let themeNames = ['Dark', 'Xtra Dark', 'Contrast', 'Color Blind', 'Light Mode'];
        for (let i = 0; i < themeNames.length; i++) {
          let tx = x + 35 * scale + (i % 3) * 115 * scale;
          let ty = contentY + 32 * scale + Math.floor(i / 3) * 32 * scale;
          if (mouseX >= tx && mouseX <= tx + 105 * scale && mouseY >= ty && mouseY <= ty + 26 * scale) {
            game.settings.currentTheme = themeNames[i]; saveGame(); return;
          }
        }

        for (let i = 0; i < ACCENT_PRESETS.length; i++) {
          let ax = x + 150 * scale + i * 35 * scale;
          if (dist(mouseX, mouseY, ax, contentY + 105 * scale) < 15 * scale) {
            game.settings.accentColor = ACCENT_PRESETS[i]; saveGame(); return;
          }
        }

        if (mouseX >= x + 150 * scale && mouseX <= x + 215 * scale && mouseY >= contentY + 133 * scale && mouseY <= contentY + 157 * scale) {
          game.settings.starsEnabled = !game.settings.starsEnabled; saveGame(); return;
        }

        if (mouseX >= x + 330 * scale && mouseX <= x + 395 * scale && mouseY >= contentY + 133 * scale && mouseY <= contentY + 157 * scale) {
          game.settings.showFPS = !game.settings.showFPS; saveGame(); return;
        }

        let fpsOpts = [30, 60, 120];
        for (let i = 0; i < fpsOpts.length; i++) {
          let fx = x + 535 * scale + i * 40 * scale;
          if (mouseX >= fx && mouseX <= fx + 35 * scale && mouseY >= contentY + 133 * scale && mouseY <= contentY + 157 * scale) {
            game.settings.targetFPS = fpsOpts[i]; frameRate(fpsOpts[i]); saveGame(); return;
          }
        }

        if (mouseX >= x + 160 * scale && mouseX <= x + 300 * scale && mouseY >= contentY + 175 * scale && mouseY <= contentY + 195 * scale) {
          game.settings.starCount = Math.round(map(mouseX, x + 160 * scale, x + 300 * scale, 40, 300)); rebuildStars(); saveGame(); return;
        }
        if (mouseX >= x + 160 * scale && mouseX <= x + 300 * scale && mouseY >= contentY + 215 * scale && mouseY <= contentY + 235 * scale) {
          game.settings.uiScale = constrain(map(mouseX, x + 160 * scale, x + 300 * scale, 0.8, 1.4), 0.8, 1.4); saveGame(); return;
        }
        if (mouseX >= x + 160 * scale && mouseX <= x + 300 * scale && mouseY >= contentY + 255 * scale && mouseY <= contentY + 275 * scale) {
          game.settings.brightness = constrain(map(mouseX, x + 160 * scale, x + 300 * scale, 0.5, 1.5), 0.5, 1.5); saveGame(); return;
        }
        if (mouseX >= x + 420 * scale && mouseX <= x + 490 * scale && mouseY >= contentY + 251 * scale && mouseY <= contentY + 277 * scale) {
          game.settings.fullscreen = !game.settings.fullscreen; fullscreen(game.settings.fullscreen); saveGame(); return;
        }
      } else if (game.activeTab === 'CONTROLS') {
        let keyList = ["shop", "planets", "pause", "click"];
        game.upgrades.forEach(u => keyList.push(`upg_${u.id}`));
        let cols = 2; let colW = (w - 70 * scale) / cols;

        for (let i = 0; i < keyList.length; i++) {
          let col = i % cols; let row = Math.floor(i / cols);
          let kx = x + 30 * scale + col * colW;
          let ky = contentY + 15 * scale + row * 28 * scale;
          if (mouseX >= kx + colW - 70 * scale && mouseX <= kx + colW - 5 * scale && mouseY >= ky - 10 * scale && mouseY <= ky + 10 * scale) {
            game.remappingKeyId = keyList[i]; return;
          }
        }
      } else if (game.activeTab === 'GAMEPLAY') {
        if (mouseX >= x + w - 130 * scale && mouseX <= x + w - 50 * scale && mouseY >= contentY + 14 * scale && mouseY <= contentY + 46 * scale) {
          game.settings.spacebarClicking = !game.settings.spacebarClicking; saveGame(); return;
        }
      } else if (game.activeTab === 'DATA') {
        let rW = 240 * scale; let rH = 38 * scale;
        let rX = width / 2 - rW / 2; let rY = contentY + 55 * scale;
        if (mouseX >= rX && mouseX <= rX + rW && mouseY >= rY && mouseY <= rY + rH) {
          resetAllSettingsDefaults(); saveGame(); return;
        }

        let delW = 240 * scale; let delH = 38 * scale;
        let delX = width / 2 - delW / 2; let delY = contentY + 105 * scale;
        if (mouseX >= delX && mouseX <= delX + delW && mouseY >= delY && mouseY <= delY + delH) {
          game.activeOverlay = 'CONFIRM_DELETE'; game.deleteInputText = ''; game.deleteInputActive = true; game.deleteWipesWizard = false; return;
        }

        let fullW = 260 * scale; let fullH = 42 * scale;
        let fullX = width / 2 - fullW / 2; let fullY = contentY + 160 * scale;
        if (mouseX >= fullX && mouseX <= fullX + fullW && mouseY >= fullY && mouseY <= fullY + fullH) {
          game.activeOverlay = 'CONFIRM_DELETE'; game.deleteInputText = ''; game.deleteInputActive = true; game.deleteWipesWizard = true; return;
        }
      }

      if (game.activeTab !== 'DATA') {
        let rW = 160 * scale; let rH = 32 * scale;
        let rX = x + 25 * scale; let rY = y + h - 55 * scale;
        if (mouseX >= rX && mouseX <= rX + rW && mouseY >= rY && mouseY <= rY + rH) {
          resetTabDefaults(game.activeTab); saveGame(); return;
        }
      }
    }

    let closeW = 100 * scale; let closeH = 38 * scale;
    let closeX = x + w - closeW - 25 * scale; let closeY = y + h - 55 * scale;
    if (mouseX >= closeX && mouseX <= closeX + closeW && mouseY >= closeY && mouseY <= closeY + closeH) {
      game.activeOverlay = null; game.remappingKeyId = null;
    }
    return;
  }

  if (game.gameState === 'MAIN_MENU') {
    let menuBtns = [];
    if (hasSaveFile()) menuBtns.push({ label: "CONTINUE", action: "CONTINUE" });
    menuBtns.push({ label: "NEW GAME", action: "NEW_GAME" });
    menuBtns.push({ label: "ACHIEVEMENTS", action: "ACHIEVEMENTS" });
    menuBtns.push({ label: "OPTIONS", action: "SETTINGS" });
    menuBtns.push({ label: "LINKS / COMMUNITY", action: "LINKS" });
    menuBtns.push({ label: "HELP / INSTRUCTIONS", action: "HELP" });

    let btnW = 220 * game.settings.uiScale;
    let btnH = 44 * game.settings.uiScale;
    let startX = 60; let startY = height * 0.30;
    let gap = 12 * game.settings.uiScale;

    for (let i = 0; i < menuBtns.length; i++) {
      let bx = startX; let by = startY + i * (btnH + gap);
      if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= by && mouseY <= by + btnH) {
        triggerMenuAction(menuBtns[i].action);
        return;
      }
    }

    let credW = 100 * game.settings.uiScale;
    let credH = 36 * game.settings.uiScale;
    let credX = startX;
    let credY = startY + menuBtns.length * (btnH + gap) + 10;
    if (mouseX >= credX && mouseX <= credX + credW && mouseY >= credY && mouseY <= credY + credH) {
      game.activeOverlay = 'CREDITS'; game.creditsTargetScrollY = 0; game.creditsStartTimer = 0; game.isCreditsAutoScrolling = true; return;
    }

    let exitW = 100 * game.settings.uiScale;
    let exitH = 36 * game.settings.uiScale;
    let exitX = startX + credW + 15;
    let exitY = credY;
    if (mouseX >= exitX && mouseX <= exitX + exitW && mouseY >= exitY && mouseY <= exitY + exitH) {
      window.close();
    }
    return;
  }

  if (game.gameState === 'PAUSED') {
    let btnW = 220 * game.settings.uiScale;
    let btnH = 48 * game.settings.uiScale;
    let startY = height * 0.36;
    let gap = 16 * game.settings.uiScale;
    let bx = width / 2 - btnW / 2;

    if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= startY && mouseY <= startY + btnH) { game.gameState = 'PLAYING'; return; }
    if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= startY + (btnH + gap) && mouseY <= startY + (btnH + gap) + btnH) { game.activeOverlay = 'ACHIEVEMENTS'; return; }
    if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= startY + 2 * (btnH + gap) && mouseY <= startY + 2 * (btnH + gap) + btnH) { game.activeOverlay = 'SETTINGS'; return; }
    if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= startY + 3 * (btnH + gap) && mouseY <= startY + 3 * (btnH + gap) + btnH) { game.activeOverlay = 'HELP'; return; }
    if (mouseX >= bx && mouseX <= bx + btnW && mouseY >= startY + 4 * (btnH + gap) && mouseY <= startY + 4 * (btnH + gap) + btnH) { saveGame(); game.gameState = 'MAIN_MENU'; game.activeOverlay = null; return; }
    return;
  }

  if (game.gameState === 'PLAYING') {
    let scale = game.settings.uiScale;
    if (!game.shopOpen && !game.planetSelectOpen) {
      let pbx = 20; let pby = height - 60;
      let pbw = 130 * scale; let pbh = 40 * scale;
      if (mouseX >= pbx && mouseX <= pbx + pbw && mouseY >= pby && mouseY <= pby + pbh) {
        game.gameState = 'PAUSED'; return;
      }
    }

    let ast = game.asteroid;
    if (ast.active && dist(mouseX, mouseY, ast.x, ast.y) < ast.size) {
      let clickPower = game.upgrades.filter(u => u.type === 'click').reduce((sum, u) => sum + (u.level * u.power), 0);
      let bonus = Math.max(50, Math.floor(game.clicks * 0.1) + clickPower * 25);
      game.clicks += bonus; ast.active = false; game.stats.cometsClicked += 1;
      checkAchievements(); game.floatTexts.push(new FloatText(mouseX, mouseY, `+${formatCost(bonus)} GOLDEN COMET!`));
      for (let i = 0; i < 25; i++) game.particles.push(new Particle(mouseX, mouseY, [255, 225, 50]));
      saveGame(); return;
    }

    let dark = game.darkAsteroid;
    if (dark.active && dist(mouseX, mouseY, dark.x, dark.y) < dark.size) {
      let clickPower = game.upgrades.filter(u => u.type === 'click').reduce((sum, u) => sum + (u.level * u.power), 0);
      let bonus = Math.max(150, Math.floor(game.clicks * 0.2) + clickPower * 50);
      game.clicks += bonus; dark.active = false; game.stats.darkCometsClicked += 1;
      checkAchievements(); game.floatTexts.push(new FloatText(mouseX, mouseY, `+${formatCost(bonus)} VOID ASTEROID!`));
      for (let i = 0; i < 30; i++) game.particles.push(new Particle(mouseX, mouseY, [180, 50, 255]));
      saveGame(); return;
    }

    if (game.planetSelectOpen) {
      let relMouseY = mouseY - game.planetMenuY;
      let closeY = height - 65 * scale;
      if (mouseX >= width / 2 - 50 * scale && mouseX <= width / 2 + 50 * scale && relMouseY >= closeY && relMouseY <= closeY + 40 * scale) {
        game.planetSelectOpen = false; return;
      }

      let cols = 4;
      let cardWidth = 140 * scale; let cardHeight = 175 * scale;
      let gapX = 25 * scale; let gapY = 25 * scale;
      let startX = (width - (cols * cardWidth + (cols - 1) * gapX)) / 2;
      let startY = 75 * scale;

      for (let i = 0; i < game.planets.length; i++) {
        let col = i % cols; let row = Math.floor(i / cols);
        let px = startX + col * (cardWidth + gapX);
        let py = startY + row * (cardHeight + gapY) - game.planetScrollY;

        if (mouseX >= px && mouseX <= px + cardWidth && relMouseY >= py && relMouseY <= py + cardHeight && relMouseY >= startY && relMouseY <= height - 80 * scale) {
          let p = game.planets[i];
          let custW = 90 * scale; let custH = 24 * scale;
          let custX = px + cardWidth / 2 - custW / 2; let custY = py + 138 * scale;

          if (p.unlocked && mouseX >= custX && mouseX <= custX + custW && relMouseY >= custY && relMouseY <= custY + custH) {
  game.activePlanetIndex = i;
  game.activeOverlay = 'CUSTOMIZE_PLANET';
  return;
}

          if (p.unlocked) { game.activePlanetIndex = i; }
          else if (game.clicks >= p.cost) { game.clicks -= p.cost; p.unlocked = true; game.activePlanetIndex = i; }
          checkAchievements(); saveGame(); break;
        }
      }
      return;
    }

    if (!game.shopOpen && mouseX >= 20 && mouseX <= 140 * scale && mouseY >= 20 && mouseY <= 60 * scale) {
      game.planetSelectOpen = true; return;
    }

    let isOverToggle = game.shopOpen 
      ? (mouseX >= game.sidebarX + 255 && mouseX <= game.sidebarX + 305 && mouseY >= 20 && mouseY <= 60)
      : (mouseX >= width - 145 && mouseX <= width - 20 && mouseY >= 20 && mouseY <= 60);

    if (isOverToggle) { game.shopOpen = !game.shopOpen; return; }  

    if (dist(mouseX, mouseY, game.x, game.y) < game.currentSize / 2) {
      triggerPlanetClick(); return;
    }

    if (game.shopOpen) {
      let rX = game.sidebarX + 20; let rY = height - 55;
      let rW = 280; let rH = 40;
      if (game.clicks >= game.rebirthCost && mouseX >= rX && mouseX <= rX + rW && mouseY >= rY && mouseY <= rY + rH) {
        performRebirth();
        return;
      }

      let availableUpgs = game.upgrades.filter(u => game.planets[u.reqPlanet].unlocked);
      let btnWidth = 280; let btnHeight = 90;
      let startX = game.sidebarX + 20; let startY = 85; let spacingY = 105;

      for (let i = 0; i < availableUpgs.length; i++) {
        let currentY = startY + (i * spacingY) - game.scrollY;
        if (mouseX >= startX && mouseX <= startX + btnWidth && mouseY >= currentY && mouseY <= currentY + btnHeight && currentY >= startY && currentY + btnHeight <= height - 65) {
          buyUpgrade(availableUpgs[i]); saveGame(); break;
        }
      }
    }
  }
}

function triggerMenuAction(act) {
  if (act === 'CONTINUE') { loadGame(); game.gameState = 'PLAYING'; }
  else if (act === 'NEW_GAME') { resetGameData(); saveGame(); game.gameState = 'PLAYING'; }
  else if (act === 'ACHIEVEMENTS') game.activeOverlay = 'ACHIEVEMENTS';
  else if (act === 'SETTINGS') game.activeOverlay = 'SETTINGS';
  else if (act === 'LINKS') game.activeOverlay = 'LINKS';
  else if (act === 'HELP') game.activeOverlay = 'HELP';
}

function triggerPlanetClick() {
  game.targetSize = game.baseSize * 0.88;
  game.currentSize = game.targetSize;

  let clickPower = game.upgrades.filter(u => u.type === 'click').reduce((sum, u) => sum + (u.level * u.power), 0);
  clickPower *= (1 + game.rebirths * 0.1);
  
  game.clicks += clickPower;
  checkAchievements();
  game.floatTexts.push(new FloatText(game.x, game.y, `+${formatCost(clickPower)}`));
  let activeCol = game.planets[game.activePlanetIndex].color;
  for (let i = 0; i < 12; i++) {
    game.particles.push(new Particle(game.x, game.y, activeCol));
  }
}

function keyPressed() {
  if (game.remappingKeyId) {
    let kStr = key.toUpperCase();
    if (keyCode === ESCAPE) kStr = 'ESCAPE';
    if (keyCode === 32) kStr = 'SPACE';
    game.settings.keys[game.remappingKeyId] = kStr;
    game.remappingKeyId = null;
    saveGame();
    return false;
  }

  if (game.activeOverlay === 'SETTINGS') {
    let tabs = ['GENERAL', 'VIDEO', 'CONTROLS', 'GAMEPLAY', 'DATA'];
    let curIdx = tabs.indexOf(game.activeTab);
    if (key.toUpperCase() === 'Q') {
      game.activeTab = tabs[(curIdx - 1 + tabs.length) % tabs.length];
      return false;
    } else if (key.toUpperCase() === 'E') {
      game.activeTab = tabs[(curIdx + 1) % tabs.length];
      return false;
    }
  }

  if (game.activeOverlay === 'CONFIRM_DELETE' && game.deleteInputActive) {
    if (keyCode === BACKSPACE) { game.deleteInputText = game.deleteInputText.slice(0, -1); return false; }
    else if (key.length === 1 && game.deleteInputText.length < 10) { game.deleteInputText += key; return false; }
  }

  let pauseKey = game.settings.keys.pause;
  let matchesPause = (pauseKey === 'ESCAPE' && keyCode === ESCAPE) || (key.toUpperCase() === pauseKey);

  if (matchesPause) {
    if (game.activeOverlay) { game.activeOverlay = null; return; }
    if (game.gameState === 'PLAYING') { game.gameState = 'PAUSED'; return; }
    if (game.gameState === 'PAUSED') { game.gameState = 'PLAYING'; return; }
  }

  if (game.gameState === 'MAIN_MENU') {
    let menuBtns = [];
    if (hasSaveFile()) menuBtns.push({ label: "CONTINUE", action: "CONTINUE" });
    menuBtns.push({ label: "NEW GAME", action: "NEW_GAME" });
    menuBtns.push({ label: "ACHIEVEMENTS", action: "ACHIEVEMENTS" });
    menuBtns.push({ label: "OPTIONS", action: "SETTINGS" });
    menuBtns.push({ label: "LINKS / COMMUNITY", action: "LINKS" });
    menuBtns.push({ label: "HELP / INSTRUCTIONS", action: "HELP" });

    if (keyCode === UP_ARROW || key.toUpperCase() === 'W') {
      game.selectedMenuIndex = (game.selectedMenuIndex - 1 + menuBtns.length) % menuBtns.length;
    } else if (keyCode === DOWN_ARROW || key.toUpperCase() === 'S') {
      game.selectedMenuIndex = (game.selectedMenuIndex + 1) % menuBtns.length;
    } else if (keyCode === ENTER || keyCode === 32) {
      triggerMenuAction(menuBtns[game.selectedMenuIndex].action);
    }
  }

  if (game.gameState === 'PLAYING') {
    if (key.toUpperCase() === game.settings.keys.shop) {
      game.shopOpen = !game.shopOpen; if (game.shopOpen) game.planetSelectOpen = false; return;
    }
    if (key.toUpperCase() === game.settings.keys.planets) {
      game.planetSelectOpen = !game.planetSelectOpen; if (game.planetSelectOpen) game.shopOpen = false; return;
    }
    if (game.settings.spacebarClicking && (keyCode === 32 || key.toUpperCase() === game.settings.keys.click)) {
      triggerPlanetClick(); return;
    }

    let pressedKey = key.toUpperCase();
    if (keyCode === 32) pressedKey = 'SPACE';
    let availableUpgs = game.upgrades.filter(u => game.planets[u.reqPlanet].unlocked);
    for (let u of availableUpgs) {
      if (game.settings.keys[`upg_${u.id}`] === pressedKey) {
        buyUpgrade(u); saveGame(); break;
      }
    }
  }
}

function mouseWheel(event) {
  if (game.activeOverlay === 'CREDITS') {
    game.isCreditsAutoScrolling = false;
    let scale = game.settings.uiScale;
    let h = min(560 * scale, height - 40);
    let visibleH = h - 140 * scale;
    let maxScroll = max(0, game.creditsContentHeight - visibleH);
    game.creditsTargetScrollY += event.delta;
    game.creditsTargetScrollY = constrain(game.creditsTargetScrollY, 0, maxScroll);
    return false;
  }

  if (game.activeOverlay === 'ACHIEVEMENTS') {
    let scale = game.settings.uiScale;
    let h = min(500 * scale, height - 60);
    let startY = height / 2 - h / 2 + 65 * scale;
    let visibleH = h - 130 * scale;
    let maxScroll = max(0, game.achievementsContentHeight - visibleH);
    game.achievementsTargetScrollY += event.delta;
    game.achievementsTargetScrollY = constrain(game.achievementsTargetScrollY, 0, maxScroll);
    return false;
  }

  if (game.gameState === 'PLAYING') {
    if (game.planetSelectOpen) {
      let scale = game.settings.uiScale;
      let startY = 75 * scale;
      let visibleHeight = height - startY - 80 * scale;
      let maxScroll = max(0, game.planetContentHeight - visibleHeight);
      game.planetTargetScrollY += event.delta;
      game.planetTargetScrollY = constrain(game.planetTargetScrollY, 0, maxScroll);
      return false;
    }
    if (game.shopOpen && mouseX >= game.sidebarX) {
      let startY = 85;
      let maxScroll = max(0, game.shopContentHeight - (height - startY - 65));
      game.targetScrollY += event.delta;
      game.targetScrollY = constrain(game.targetScrollY, 0, maxScroll);
      return false;
    }
  }
}

function calculateCPS() {
  let availableUpgs = game.upgrades.filter(u => game.planets[u.reqPlanet].unlocked);
  let baseCPS = availableUpgs.filter(u => u.type === 'cps').reduce((sum, u) => sum + (u.level * u.power), 0);
  let mult = availableUpgs.filter(u => u.type === 'multiplier').reduce((sum, u) => sum + (u.level * u.power), 1);
  return baseCPS * mult * (1 + game.rebirths * 0.1);
}

function buyUpgrade(upg) {
  if (game.clicks >= upg.cost) {
    game.clicks -= upg.cost;
    upg.level += 1;
    upg.cost = Math.floor(upg.cost * 3.2);
    game.stats.totalUpgradesBought += 1;
    checkAchievements();
  }
}

function drawShopToggleButton() {
  if (game.shopOpen) return;
  let theme = getTheme();
  let scale = game.settings.uiScale;
  
  let isHovered = mouseX >= width - 145 && mouseX <= width - 20 && mouseY >= 20 && mouseY <= 60;
  stroke(theme.accent[0], theme.accent[1], theme.accent[2]); strokeWeight(1);
  fill(isHovered ? color(theme.sidebar[0] + 15, theme.sidebar[1] + 15, theme.sidebar[2] + 25) : color(theme.panel[0], theme.panel[1], theme.panel[2]));
  rect(width - 145, 20, 125 * scale, 40 * scale, 6);
  
  noStroke(); fill(255); textSize(13 * scale); textStyle(BOLD); textAlign(CENTER, CENTER);
  text(`Upgrades [${game.settings.keys.shop}]`, width - 145 + (125 * scale) / 2, 20 + (40 * scale) / 2); 
}

function drawShop() {
  let theme = getTheme();
  let sidebarWidth = 320;
  let btnWidth = 280;
  let btnHeight = 90;
  let startX = game.sidebarX + 20;
  let startY = 85;
  let spacingY = 105;

  let availableUpgs = game.upgrades.filter(u => game.planets[u.reqPlanet].unlocked);
  game.shopContentHeight = availableUpgs.length * spacingY;
  game.scrollY = lerp(game.scrollY, game.targetScrollY, 0.25);
  
  noStroke(); fill(theme.sidebar[0], theme.sidebar[1], theme.sidebar[2]);
  rect(game.sidebarX, 0, sidebarWidth, height);
  
  textStyle(NORMAL);
  for (let i = 0; i < availableUpgs.length; i++) {
    let upg = availableUpgs[i];
    let currentY = startY + (i * spacingY) - game.scrollY;
    if (currentY + btnHeight < startY || currentY > height - 60) continue;
    
    let isHovered = mouseX >= startX && mouseX <= startX + btnWidth && mouseY >= currentY && mouseY <= currentY + btnHeight;
    let canAfford = game.clicks >= upg.cost;
    upg.currentHover = lerp(upg.currentHover, isHovered ? 1 : 0, 0.4);
    
    fill(!canAfford ? color(25, 25, 45, 150) : color(30 + upg.currentHover * 15, 30 + upg.currentHover * 15, 55 + upg.currentHover * 25));
    stroke(!canAfford ? color(45, 45, 70) : color(theme.accent[0], theme.accent[1], theme.accent[2], 100 + upg.currentHover * 155));
    strokeWeight(1 + upg.currentHover);
    rect(startX, currentY, btnWidth, btnHeight, 10);
    
    noStroke(); textAlign(LEFT, CENTER); fill(255); textSize(15); textStyle(BOLD);
    text(`[${upg.id}] ${upg.name}`, startX + 16, currentY + 24);
    textStyle(NORMAL); fill(150, 160, 190); textSize(13);
    
    if (upg.type === 'click') text(`Lvl ${upg.level} (+${formatCost(upg.power)}/click)`, startX + 16, currentY + 48);
    else if (upg.type === 'multiplier') text(`Lvl ${upg.level} (+${(upg.power * 100)}% CPS)`, startX + 16, currentY + 48);
    else text(`Lvl ${upg.level} (+${formatCost(upg.power)} CPS)`, startX + 16, currentY + 48);
    
    fill(canAfford ? color(75, 210, 140) : color(230, 95, 115));
    textSize(14); textStyle(BOLD);
    text(`¤ ${formatCost(upg.cost)}`, startX + 16, currentY + 70);
  }

  noStroke(); fill(theme.sidebar[0], theme.sidebar[1], theme.sidebar[2]);
  rect(game.sidebarX, 0, sidebarWidth, startY - 5);
  stroke(35, 35, 65); line(game.sidebarX, 0, game.sidebarX, height);
  
  let isCloseHovered = mouseX >= game.sidebarX + 255 && mouseX <= game.sidebarX + 305 && mouseY >= 20 && mouseY <= 60;
  stroke("coral"); strokeWeight(1); fill(isCloseHovered ? color(60, 20, 20) : color(35, 15, 15));
  rect(game.sidebarX + 255, 20, 50, 40, 6);
  noStroke(); fill(255); textSize(14); textStyle(BOLD); textAlign(CENTER, CENTER);
  text("X", game.sidebarX + 280, 40);
  fill(255); textSize(20); textStyle(BOLD); textAlign(LEFT, TOP);
  text("UPGRADES", startX, 30);

  let rX = game.sidebarX + 20; let rY = height - 55;
  let rW = 280; let rH = 40;
  let canRebirth = game.clicks >= game.rebirthCost;
  stroke(canRebirth ? color(255, 215, 0) : color(80)); strokeWeight(1);
  fill(canRebirth ? color(60, 50, 10) : color(25, 25, 35));
  rect(rX, rY, rW, rH, 6);
  noStroke(); fill(canRebirth ? color(255, 215, 0) : color(140));
  textSize(12); textStyle(BOLD); textAlign(CENTER, CENTER);
  text(`REBIRTH #${game.rebirths + 1} (Cost: ¤${formatCost(game.rebirthCost)})`, rX + rW / 2, rY + rH / 2);
}

class Particle {
  constructor(startX, startY, themeColor) {
    this.x = startX; this.y = startY;
    let angle = random(TWO_PI); let speed = random(2.5, 6.5);
    this.vx = cos(angle) * speed; this.vy = sin(angle) * speed;
    this.alpha = 255; this.size = random(3, 9);
    this.col = themeColor || [0, 220, 255];
  }
  update() { this.x += this.vx; this.y += this.vy; this.vy += 0.08; this.alpha -= 12; }
  display() { noStroke(); fill(this.col[0], this.col[1], this.col[2], this.alpha); circle(this.x, this.y, this.size); }
  isDead() { return this.alpha <= 0; }
}

class FloatText {
  constructor(startX, startY, label) {
    this.x = startX + random(-12, 12); this.y = startY;
    this.label = label; this.alpha = 255; this.vy = random(-1.5, -3);
  }
  update() { this.y += this.vy; this.alpha -= 6; }
  display() {
    textSize(18 * game.settings.uiScale); textStyle(BOLD); textAlign(CENTER, CENTER);
    fill(100, 255, 200, this.alpha); text(this.label, this.x, this.y);
  }
  isDead() { return this.alpha <= 0; }
}